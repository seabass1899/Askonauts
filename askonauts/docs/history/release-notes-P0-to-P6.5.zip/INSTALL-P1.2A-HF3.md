# Install P1.2A-HF3

Extract this package over the current ASKONAUTS project root and replace matching files.
Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
npm run dev
```

## Responsive smoke test

1. Open the game in the same ultrawide browser window used to test HF2.
2. Confirm the entire Observation Screen remains visible.
3. Confirm the title and Parent control remain visible.
4. Confirm Quip's experiment ring is not clipped at the bottom.
5. Confirm the lamp has breathing room from the left edge.
6. Resize the browser narrower and wider; the complete 16:9 gameplay frame should always remain visible.
7. Extra horizontal/vertical browser area should show subdued Light Lab ambience instead of plain navy bars.
