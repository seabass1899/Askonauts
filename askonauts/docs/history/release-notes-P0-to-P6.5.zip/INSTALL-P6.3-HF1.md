# Install P6.3-HF1

Apply this overlay on top of ASKONAUTS P6.3.

1. Extract this ZIP into the project root and allow files to overwrite.
2. Run:

```bat
npm run build
npm run dev
```

3. Hard refresh the browser with `Ctrl + F5` if cached assets remain visible.
