# P2.1-HF2 changes

- Live ASKONAUT badge preview
- Child-facing onboarding copy
- Character reactions during identity selection
- `JOIN THE TEAM` confirmation
- Spark/badge welcome celebration
- Personalized team welcome
- `SAVE MY BADGE` edit flow
- Build marker `P2.1-HF2`
