# Install P5.2-HF2

Copy the overlay contents into the project root, allowing replacement of matching files.

Then:

```bat
npm run build
npm run dev
```

Hard refresh the browser with Ctrl+F5.
