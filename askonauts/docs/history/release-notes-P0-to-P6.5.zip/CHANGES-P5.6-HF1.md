# ASKONAUTS P5.6-HF1 — Trophy Shelf Layout Cleanup

## Changes
- Moved Discovery Trophies out of the character stage and into a dedicated wall-mounted display beneath the Discovery Wall.
- Added a trophy backboard, title, shelf plank, and tap hint for clearer visual grouping.
- Kept trophy interactions and recap bubbles intact.
- Raised trophy display depth so the wall unit reads clearly while remaining spatially separate from Veya, Quip, and Teyo.
- Updated the Clubhouse build marker to P5.6-HF1.

## Unchanged
- Progression logic
- Mission mastery logic
- Curiosity Sparks
- Discovery Journal
- Question Tree
- Character placement / art
- Save data
