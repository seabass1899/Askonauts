# ASKONAUTS P4.5-HF1 — Animated Spoon + Expressive Reflection

This hotfix builds on P4.5 and upgrades Spoon Lab presentation without changing science/progression logic.

## Added
- Animated spoon flip (~500 ms): edge-on turn, side swap, shimmer, settle.
- Rapid repeat taps are ignored while the spoon is flipping.
- Concave and convex sides now have distinct metallic shading/highlight treatment.
- New reusable `ViewerFace` component with hair, brows, pupils/highlights, nose, cheeks, and expression states.
- Viewer and reflected image use the same visual identity.
- Reflection smoothly transitions between upright/inverted and small/large states.
- Viewer moves along the FAR/MIDDLE/NEAR rail with a tween instead of snapping.
- Viewer reacts to reflection flips, discoveries, challenge completion, and Spoon Mastery.
- Spoon Mastery gets a small shimmer/reaction celebration.

## Unchanged
- clue IDs and unlock rules
- challenge IDs and success conditions
- Curiosity Sparks
- PlayerProgressStore / save schema
- Question Tree
- Discovery Journal
- age band / ASKONAUT identity
- Clubhouse navigation

Apply over ASKONAUTS P4.5.
