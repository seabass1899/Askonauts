# ASKONAUTS P2.0-HF1 — Clubhouse Character Canon Correction

This hotfix preserves the P2.0 Clubhouse systems and corrects the on-screen cast presentation.

## Changes
- Veya corrected to a warmer, melanin-rich complexion while preserving her canonical pink hoodie, cargo pants, red high-tops, ponytail and satchel.
- Teyo corrected to a warmer, melanin-rich complexion while preserving his goggles, blue builder outfit, tool belt and silhouette.
- Removed a stray extraction artifact from the Teyo asset.
- Increased Veya and Teyo's visual presence in the Clubhouse.
- Reduced Quip slightly so all three characters read as one ensemble rather than Quip dominating the composition.
- Updated the Clubhouse build marker to P2.0-HF1.

## Unchanged
- PlayerProgressStore
- WorldRegistry
- Question Compass logic
- Question Gate logic
- Discovery Wall persistence
- Spark Vessel persistence
- Shadow Chase launch/return flow

## Install
Extract over the existing P2.0 project root and replace files.

Then run:

    npm run build
    npm run dev
