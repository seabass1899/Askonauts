# ASKONAUTS — Shadow Chase P1.2C

P1.2C is the Cinematic Discovery pass. Important science observations now receive a brief environmental focus beat instead of only a UI reward: the room softens, the camera makes a restrained push, evidence Sparks arc into the Question Compass, the Compass visibly responds, and the next challenge arrives through a short transition.

## Smoke test

1. Move Quip until the shadow-follow discovery resolves.
2. Move the lamp and watch the light/shadow discovery.
3. Toggle the lamp OFF and ON.
4. Create HUGE and TINY shadows.
5. Unlock the blocker and make its shadow.
6. Confirm the Compass receives evidence during each major discovery.
7. Verify the camera always returns to normal framing and no drag behavior changes.
8. Complete Evidence Lock, Free Experiment, and Question Gate normally.

P1.2C deliberately leaves Question Gate cinematics for P1.2D.
