# P6.4A-HF6 — Spoon Interaction Affordance + Functional Controls

- Adds visible hover/press feedback to illustrated Spoon Lab controls.
- Wires all illustrated left-side activity cards to real behavior.
- Wires all illustrated right-side experiment-tool cards to real behavior.
- Keeps bottom controls functional via the illustrated control bar.
- Updates runtime marker to LIVE • P6.4A-HF6.

## Left-side controls
- Upside-Down Spoon: configures concave + farther distance to demonstrate inversion.
- Concave vs Convex: toggles spoon side.
- Spoon Sizes: cycles near/middle/far distance states.
- Creative Lab: opens Challenge Lab when the Spoon Lab mystery has been completed; otherwise explains the lock.

## Right-side controls
- Rotate: toggles spoon side.
- Zoom: cycles distance states.
- Light: plays a light/shimmer observation and explanatory voice line.
- Reset: restores the initial concave/distance state.
