# P4.0 changes

- Adds `UpsideDownSpoonScene`.
- Registers `upside-down-spoon` as a playable world.
- Adds Clubhouse Gate routing to the Spoon Lab after Reflection Hunt.
- Makes Upside-Down Spoon a playable Question Tree node.
- Adds Funhouse Mirrors as the next future-question branch.
- Adds Spoon Lab discoveries and secret to the Discovery Journal.
- Reflection Hunt completion now unlocks the Spoon Lab.
- Adds persistent Spoon Lab progress through the existing PlayerProgressStore.
