# ASKONAUTS P6.4A-HF3 — Spoon Lab Runtime Composition Cleanup

This overlay refines the live Spoon Lab layer so the illustrated environment and Phaser runtime no longer compete visually.

## Changes
- removes the four floating clue cards from the center/top of the lab
- removes the duplicate live title plate over Veya's illustrated dialogue area
- converts Sprint / Challenge / Clubhouse into invisible header hotspots over the illustrated controls
- keeps only the dynamic controls needed for the experiment
- confines the viewer movement to the central experiment zone so it no longer collides with the left UI
- reduces viewer scale and cleans the distance guide
- moves live discovery/status text into the lower-right live status area
- preserves Spoon Sprint, Challenge Lab, discoveries, secrets, Sparks, mastery, reflection behavior, and persistent Clubhouse exit

Apply over P6.4A-HF2.
