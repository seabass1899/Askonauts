# P1.2B-HF1 Changes

- Added four transparent production prop assets under `public/assets/props/`.
- Replaced procedural Telescope, Prism, Question Jar and Brass Dial rendering with Phaser Image objects.
- Added subtle idle glow/motion and stronger tap feedback without changing mission progression.
- Retained all existing optional interaction rewards and secrets.
- Added P1.2B-HF1 preload keys.
- Updated build identifier and telemetry allowlist to P1.2B-HF1.
