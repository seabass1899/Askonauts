# Install P6.3-HF2

Apply this overlay over your current ASKONAUTS P6.3/P6.3-HF1 project, preserving the included folder structure.

From the project root run:

```bat
npm run build
npm run dev
```

Then hard-refresh the browser with `Ctrl + F5`.

The Clubhouse header should show `P6.3-HF2`.
