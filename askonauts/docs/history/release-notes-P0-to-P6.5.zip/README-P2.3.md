# ASKONAUTS P2.3 — Discovery Journal

P2.3 turns saved mission discoveries into a persistent, child-facing Discovery Journal.

## What is new
- The Clubhouse Discovery Wall now opens the Discovery Journal.
- Journal entries are derived from the same saved Shadow Chase discoveries and Light Lab secrets already stored in PlayerProgressStore.
- No duplicate journal-unlock counter is introduced.
- The journal uses paged cards (six per page) for reliable landscape/mobile presentation without WebGL masking.
- Selecting a card shows:
  - discovery/secret type
  - kid-friendly summary
  - science takeaway
  - a concrete experiment prompt
- `TRY IT AGAIN` returns to Shadow Chase and carries the selected journal focus through Phaser scene/registry data for replay-aware world behavior.
- The Question Tree's completed state now reads `COMPLETED` rather than `DISCOVERED`.

## Discovery Wall contract
The wall is now the physical Clubhouse entry point into the Journal. Shadow Chase can still be revisited from the Journal and Question Tree.

## Persistence
P2.3 does not change the PlayerProgressStore schema. Existing identity, Sparks, discoveries, secrets, completion state, and profile data remain intact.
