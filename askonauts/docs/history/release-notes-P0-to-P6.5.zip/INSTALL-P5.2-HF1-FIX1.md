# Install

Apply this overlay over P5.2-HF1, then run:

npm run build
npm run dev

Hard refresh with Ctrl+F5.
