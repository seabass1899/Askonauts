# Changes
- Spoon Lab marker updated to P6.4-SPOON.
- Rebuilt Spoon Lab room as a richer observatory workshop using live Phaser graphics.
- Added premium P6 header treatment and world hierarchy.
- Added dedicated experiment-tools and discovery-status consoles.
- Upgraded experiment platform, observatory window, props, lighting, and panel styling.
- Added persistent Clubhouse exit with Esc shortcut.
- Preserved existing Spoon Sprint, Challenge Lab, clues, discoveries, voice, mission randomization, mastery, Sparks, and save data.
