# ASKONAUTS P1.2A-HF2 — Full-Screen Composition & Scene Cleanup

This hotfix is a production-composition cleanup on top of P1.2A-HF1. It does not change mission logic, thresholds, optics math, Supabase schema, or the playtest workflow.

## What changed

- Phaser scale mode changed from `FIT` to `ENVELOP` so the 16:9 game fills the landscape viewport instead of showing dead top/bottom bands.
- Outside-canvas scenic duplication was removed to prevent the repeated bottom strip.
- title / Parent controls moved into a safer center crop for ENVELOP scaling.
- Free Experiment UI is smaller and retracts after a short read window; progress briefly brings it back.
- Quip / blocker depths now follow floor position so overlapping objects read more naturally.
- new P1.2A-HF2 Quip shadow textures use a true alpha silhouette and local penumbra instead of a broad grey wash.
- blocker shadow is lighter and less synthetic.
- Question Gate backdrop/card are smaller and more translucent so the Light Lab remains visible during the reward choice.
- build / telemetry ID is `P1.2A-HF2`.

## What did not change

- mission progression
- drag rules and gameplay bounds
- discovery thresholds
- Question Compass evidence logic
- Free Experiment count (5)
- Question Gate progression semantics
- telemetry schema
