# Install — P5.6-HF2

Apply this overlay over ASKONAUTS P5.6-HF1.

Then run:

```bat
npm run build
npm run dev
```

If your browser still shows cached layout, use `Ctrl + F5`.
