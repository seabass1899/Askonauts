# Install P1.2B-HF4

Extract this ZIP into the existing ASKONAUTS project root and choose **Replace files in destination**.

Project root used during development:

`C:\projects\Askonauts\askonauts-shadow-box-p0.5.2\askonauts-shadow-box-p0.5.2`

Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
```

If clean:

```bat
npm run dev
```

The title should show `P1.2B-HF4`.
