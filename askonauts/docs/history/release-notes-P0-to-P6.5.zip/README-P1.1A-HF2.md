# ASKONAUTS P1.1A-HF2 — Quip Ear + Shadow Hotfix

This hotfix replaces Quip's runtime idle sprite with a corrected full-ear silhouette and removes the procedural ear overlay from `QuipCharacter.ts`.

It also replaces both Quip shadow textures so the observation-screen silhouette matches the corrected ears.

Build identifier: `P1.1A-HF2`.

No gameplay geometry, mission progression, telemetry fields, drag zones, or optics math are changed.
