# ASKONAUTS P1.2A-HF1 — Production Composition

This hotfix is a composition-quality pass on top of P1.2A. It does not change the Shadow Chase science or mission thresholds.

## Main changes

- smaller, retracting mission/challenge HUD so the Light Lab stays visible
- reduced observation-screen dominance and more usable negative space around Quip
- less editor-like floor grid and a smoother scenic-to-floor transition
- cleaner foreground composition and quieter experiment pad
- corrected shadow rendering with transparent soft-shadow assets and strict screen containment
- Quip/blocker shadows can still become visibly large, but no longer spill as grey rectangles outside the screen
- non-16:9 browser letterbox area now uses a darkened Light Lab scenic fill rather than flat navy
- build/telemetry identifier updated to `P1.2A-HF1`

## Preserved

- optics math and discovery thresholds
- Quip, light and blocker dragging
- Evidence Lock
- Free Experiment
- Question Gate
- parent/playtest workflow
- Supabase schema
