# Install P4.6-HF1

Apply this overlay on top of the existing P4.6 Funhouse Mirrors FIX1 project.

Then run:

```bat
npm run build
npm run dev
```

Verify:
1. FLAT displays `FLAT MIRROR` and a straight-edged frame.
2. TALL displays `VERTICALLY CURVED MIRROR`.
3. WIDE displays `HORIZONTALLY CURVED MIRROR`.
4. WAVY displays `MIXED-CURVE MIRROR`.
5. Question Tree cards for Upside-Down Spoon and Funhouse Mirrors do not overlap.
