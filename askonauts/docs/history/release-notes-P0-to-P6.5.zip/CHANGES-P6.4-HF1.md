# P6.4-HF1 Changes

- Version sync: Clubhouse and Reflection Lab now identify as P6.4-HF1.
- Persistent navigation: Reflection Lab CLUBHOUSE control renders above all challenge/completion overlays.
- Added ESC shortcut back to Clubhouse from Reflection Lab.
