# Install — P4.5-HF2-FIX2

Apply this overlay over the current working **P4.5-HF2 FIX1** project.

Then run:

```bat
npm run build
npm run dev
```

Verify the Spoon Lab marker reads `P4.5-HF2-FIX2`, and check the viewer at FAR, MIDDLE, and NEAR.
