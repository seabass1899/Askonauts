# Install ASKONAUTS P2.3

Expected base: **P2.2-HF1**.

1. Back up the current project.
2. Extract this ZIP over the project root and replace files when prompted.
3. Run:

```bat
npm run build
npm run dev
```

## Quick validation
1. Header reads `P2.3`.
2. Tap the Discovery Wall / Shadow Chase plaque.
3. Discovery Journal opens.
4. Saved discoveries and all three Light Lab secrets appear.
5. Page controls work when more than six entries exist.
6. Tap several cards and verify the detail panel changes.
7. `TRY IT AGAIN` launches Shadow Chase.
8. Return to the Clubhouse and verify profile, Sparks, Question Tree, and progress remain intact.
