# ASKONAUTS P6.3-HF1

Focused overlay/readability cleanup for the P6.3 canonical Clubhouse reconstruction.

This package intentionally does not redesign the P6.3 composition. It removes duplicate live UI, keeps dialogue away from the character stage, and improves utility/nameplate spacing before the project proceeds to the world UI makeover phase.
