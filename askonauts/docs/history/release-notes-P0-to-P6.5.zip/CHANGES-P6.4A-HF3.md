# P6.4A-HF3 Changes

- runtime composition cleanup
- illustrated header owns visible chrome
- invisible header action hotspots replace duplicate live buttons
- removed floating clue-card row
- narrowed viewer travel to experiment zone
- reduced viewer scale
- simplified distance guide
- removed duplicate live experiment heading
- retained dynamic spoon/reflection controls and mission systems
