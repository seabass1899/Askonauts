# ASKONAUTS P5.2 — Character-Driven Missions & Reactions

P5.2 adds character ownership to the existing mission system without changing world progression, Spark rewards, discoveries, or save data.

## Mission roles
- Veya: prediction, noticing, science framing
- Teyo: practical challenge instructions and problem-solving cues
- Quip: comic pressure relief, wrong-answer recovery, celebration

## Updated worlds
- Clubhouse Mission Board now identifies each mission guide.
- Reflection Hunt LIGHT RESCUE uses Veya/Teyo/Quip mission dialogue.
- Spoon Lab SPOON SPRINT uses rotating character prompts.
- Funhouse MIRROR MISSION uses character-led prediction, retry, success, and completion reactions.
- Shadow Quest remains mechanically unchanged; Quip is identified as its guide from the Mission Board.

## Important
P5.2 does not add new currency, scoring, streaks, or progression gates.
