# Changes — P4.6-HF4

- `ReflectionHuntScene.recordDiscovery()` now returns whether a discovery was newly added.
- Discovery narration is triggered only when the corresponding discovery is new.
- Fixed repeated ANGLE MATTERS narration on every mirror rotation.
- Also prevents repeated core surface discovery narration when reselecting Mirror, Rough, or Spoon.
