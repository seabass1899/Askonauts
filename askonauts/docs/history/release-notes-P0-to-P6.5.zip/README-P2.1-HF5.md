# ASKONAUTS P2.1-HF5 — Identity Edit-State Cleanup

This hotfix refines the ASKONAUT badge editor so first-time setup and returning-player editing use distinct UI language.

## Changes

- Visible build marker: `P2.1-HF5`
- First-time onboarding continues to show:
  - `WHAT SHOULD WE CALL YOU?`
  - `CHOOSE NAME`
- Returning ASKONAUT edit mode now shows:
  - `YOUR ASKONAUT NAME`
  - saved name as an established identity plate
  - `CHANGE NAME`
- The actual text-entry control is still only shown after the player chooses to change/choose the name.
- No changes to persistence, Curiosity Sparks, world progress, mission logic, or navigation.

## Install

Extract this ZIP over the current P2.1-HF4 project root and replace files when prompted.

Then run:

```bat
npm run build
npm run dev
```

In the Clubhouse, open the ASKONAUT badge editor and verify that an existing profile shows `YOUR ASKONAUT NAME` and `CHANGE NAME`.
