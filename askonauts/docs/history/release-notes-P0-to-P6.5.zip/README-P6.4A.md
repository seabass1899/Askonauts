# ASKONAUTS P6.4A — Spoon Lab World UI Makeover

Apply over the current P6.4-HF2 project. This overlay upgrades Spoon Lab presentation while preserving existing Spoon Lab mechanics, Spoon Sprint, Challenge Lab, mission variants, discoveries, mastery, Sparks, and persistence.

Also adds a persistent Clubhouse exit and Esc-to-Clubhouse behavior in Spoon Lab.
