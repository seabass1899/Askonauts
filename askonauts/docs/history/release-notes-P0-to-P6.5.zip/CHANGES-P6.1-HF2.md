# Changes — P6.1-HF2

- Replaces the flat Phaser-drawn Clubhouse room with a high-resolution illustrated observatory environment.
- Keeps all interactive panels and data-driven UI live above the environment.
- Preserves canonical full-body Quip, Veya, and Teyo sprites.
- Adds a subtle header readability veil and animated stage glow.
- No changes to P5.9 mission logic, mastery, Sparks, discoveries, Journal, Question Tree, or persistence.
