# P5.9 Changes

- Added reusable `MissionVariantEngine` utility.
- Light Rescue now combines target count, target order, starting angle, precision, and turn-goal variables.
- Spoon Sprint now combines objective count/order, starting states, prompt style, and move-goal variables.
- Mirror Mission now combines mission length, prompt style, target order, and clue timing.
- Updated Mission Board copy to describe dynamic replay recipes.
- Updated visible world/Clubhouse markers to P5.9.
- Mastery, Sparks, discoveries, and persistent completion rules remain compatible.
