# P4.6 Changes

- Added `FunhouseMirrorsScene`.
- Promoted Funhouse Mirrors from future Question Tree node to playable world.
- Added four mirror discoveries and one secret.
- Reused `ViewerFace` for viewer/reflection identity continuity.
- Added Funhouse Mirror journal entries and replay routing.
- Registered the scene in `main.ts` and `WorldRegistry`.
- Updated Clubhouse Question Tree navigation and build marker to P4.6.
- No changes to existing Spoon Lab mechanics or saved discovery IDs.

## P4.6 FIX1
- Removed unused `mode` scene field and its write in `applyMirrorMode()` to satisfy strict TypeScript `noUnusedLocals`.
- No gameplay or visual behavior changed.
