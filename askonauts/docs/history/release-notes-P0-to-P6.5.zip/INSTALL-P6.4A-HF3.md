# Install P6.4A-HF3

1. Extract this ZIP over your existing ASKONAUTS project that already has P6.4A-HF2 applied.
2. Allow files to overwrite when prompted.
3. Run:

```bat
npm run build
npm run dev
```

4. Hard refresh the browser with Ctrl+F5.

Expected Spoon Lab runtime marker: `LIVE • P6.4A-HF3`.
