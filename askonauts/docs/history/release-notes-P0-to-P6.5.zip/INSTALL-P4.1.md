# Install P4.1

Base: ASKONAUTS P4.0-HF1.

1. Back up the current project.
2. Extract the P4.1 ZIP over the project root and replace files.
3. Run:

   npm run build
   npm run dev

4. Confirm the Clubhouse and Spoon Lab show P4.1.
5. Revisit Upside-Down Spoon after completing the world and open CHALLENGE LAB.
