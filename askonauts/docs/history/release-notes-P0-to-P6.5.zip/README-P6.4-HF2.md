# ASKONAUTS P6.4-HF2 — Persistent Shadow Chase Exit

This hotfix prevents Shadow Chase from trapping the player inside the experiment flow.

Changes:
- Adds a persistent CLUBHOUSE button above all Shadow Chase overlays.
- Adds Esc-to-Clubhouse desktop fallback.
- Reuses one safe returnToClubhouse() path that records mission progress and stops voice playback.
- Moves the Parent control to the far-right so it does not overlap the new Clubhouse button.
- Updates the Shadow Chase scene marker to P6.4-HF2.

No discovery, mission, Spark, mastery, or save-data behavior is intentionally changed.
