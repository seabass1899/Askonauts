# Install P3.1

Expected base: **P3.0 — Reflection Hunt**.

1. Back up the working project.
2. Extract this ZIP over the project root and replace matching files.
3. Run:

```bat
npm run build
npm run dev
```

## Verify

- Reflection Lab header shows `P3.1`.
- A `CHALLENGE LAB` button appears in the Reflection Lab header.
- Challenge Lab offers Center Bounce, Sky Bounce, and Floor Bounce.
- Mirror rotates in 5-degree increments.
- Completing a target persists it as complete.
- Completing all three produces the Triple Bounce bonus secret.
- Reflection Journal shows the new challenge secrets.
- Existing ASKONAUT identity, age band, Sparks, Shadow Chase, Question Tree, and discoveries remain intact.
