# P4.1 changes

- Adds Spoon Challenge Lab.
- Adds FLIP IT, MAKE IT HUGE, and SHRINK IT challenges.
- Adds SPOON MASTER mastery secret after all three challenges.
- Persists first-time challenge completions as Spoon Lab secrets and awards Curiosity Sparks.
- Adds Spoon challenge/mastery entries to the Discovery Journal.
- Adds FAR / MIDDLE / NEAR rail labels and live distance guide.
- Keeps Challenge Lab locked until Upside-Down Spoon is solved.
- Updates Clubhouse and Spoon Lab build markers to P4.1.
- Updates package version to 4.1.0-spoon-challenges.
