# ASKONAUTS P6.3-HF2

This is a surgical overlay/readability cleanup for the canonical Clubhouse reconstruction.

It does not redesign the P6.3 composition and does not change gameplay. It removes duplicate live labels and intrusive hint overlays so the illustrated canonical UI remains visually dominant while Phaser continues to provide interaction, dynamic state, voice, progression, and navigation.
