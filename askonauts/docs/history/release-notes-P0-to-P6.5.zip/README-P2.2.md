# ASKONAUTS P2.2 — Question Compass + Question Tree

P2.2 turns the Clubhouse Question Compass into the first curiosity-driven progression map for ASKONAUTS Question World.

## What changes

- Build marker: `P2.2`
- Tapping the Question Compass opens **The Question Tree** instead of a single speech bubble.
- The tree is derived from real player progress and discoveries.
- There is no separate level-unlock score.
- Question states are:
  - **READY TO EXPLORE** — a playable question/world.
  - **DISCOVERED** — a question revealed by prior exploration.
  - **NEW QUESTION** — a newly grown branch that is not yet playable.
  - **MYSTERY** — a future question whose prerequisites have not yet been revealed.

## Initial question branches

- **Shadow Chase** — Why do shadows follow us?
- **Shadow Size** — Why does a shadow change size?
- **Reflection Hunt** — Why can we see ourselves in some things?
- **Double Shadow?** — Can one object make two shadows?
- **Upside-Down Spoon** — Why does a spoon flip your reflection?

Shadow-size state is derived from the existing `large_shadow` and `small_shadow` discoveries. Reflection Hunt is revealed by completing Shadow Chase. Future questions remain mysteries until their parent branch is resolved.

## Interaction

- Tap a question node to inspect it.
- Tap Shadow Chase a second time within the short confirmation window to enter/revisit the Light Lab.
- Reflection Hunt reports that the next Discovery World is forming because its world is not implemented yet.
- Mystery nodes give curiosity guidance rather than behaving like disabled level buttons.

## Preserved systems

P2.2 does not change:

- ASKONAUT identity or age-band/profile data
- Curiosity Sparks
- Shadow Chase mission logic
- Player progress persistence
- Discovery Wall
- Spark Vessel
- Question Gate
- voice/timing fixes

