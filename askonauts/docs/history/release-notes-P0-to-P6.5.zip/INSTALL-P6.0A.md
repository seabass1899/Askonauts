# Install P6.0A

Extract this ZIP over your current P5.9 project root, allowing files to overwrite.

Then run:

```bat
npm run build
npm run dev
```

Hard refresh the browser if an older sprite is cached:

```text
Ctrl + F5
```

Expected Clubhouse marker: `P6.0A`.
