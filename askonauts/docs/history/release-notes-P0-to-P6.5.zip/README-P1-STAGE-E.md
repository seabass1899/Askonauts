# ASKONAUTS P1.0 — Stage E: Free Experiment

Stage E turns the post-evidence moment into a purposeful, child-facing free-experiment loop without converting the mission into a quiz.

## What changes

- Build identifier: `P1.0E`
- After the Question Compass evidence lock, a compact **FREE EXPERIMENT** HUD appears.
- The prompt is intentionally open-ended: **“Change one thing. What happens?”**
- Five curiosity pips illuminate as the child makes five meaningful experiments.
- Quip reacts during the sequence so the room feels responsive rather than silent.
- On the fifth meaningful experiment, the mission advances to `question_gate` and the HUD reports **NEW QUESTION DETECTED**.
- The parent panel now shows `Free-play interactions`.
- The telemetry API accepts `P1.0E`.

## Expected local test

Immediately after locking evidence:

```text
Mission stage:          free_experiment
Mission discoveries:    12
Curiosity Sparks:       15
Free-play interactions: 0/5
```

Make five meaningful changes using Quip, the lamp, the switch, and/or the blocker. After the fifth:

```text
Mission stage:          question_gate
Mission discoveries:    13
Curiosity Sparks:       17
Free-play interactions: 5/5
```

`Mission discoveries` can be greater than 13 if the optional GIANT QUIP secret was also found.

## Install

Extract this ZIP directly over the existing ASKONAUTS project root and replace files when prompted. Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
npm run dev
```

Do not deploy to production until the local Stage E flow has been verified.
