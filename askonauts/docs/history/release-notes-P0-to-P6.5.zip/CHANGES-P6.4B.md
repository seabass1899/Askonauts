# ASKONAUTS P6.4B — Global Navigation & Systems Pass

Baseline: **P6.4A-HF8**

## Implemented

### 1. Shared application shell
- Added `GlobalGameUI` as the semantic owner of the painted header navigation.
- Spoon Lab now maps the painted header to the real actions:
  - JOURNAL
  - TREE
  - SETTINGS
  - AUDIO
  - CLUBHOUSE
- Removed the stale Spoon Lab `Sprint` and `Challenge` header hotspots that no longer matched the current artwork.
- Spoon Sprint / Challenge functionality remains available through the mission/experiment flows rather than being falsely mapped under new header labels.

### 2. Global Discovery Journal overlay
- Extracted a scene-independent `DiscoveryJournalOverlay`.
- Reads the existing `DiscoveryJournal` data model and current player progress.
- Supports paging, entry details, secrets, science explanation, and `TRY IT AGAIN` routing.
- Opens over the current scene and returns to the current scene when closed.

### 3. Global Question Tree overlay
- Added a scene-independent `QuestionTreeOverlay`.
- Uses the existing `QuestionTree` model and progress state.
- Supports completed / available / discovered / mystery states.
- World nodes route directly to the appropriate discovery world.

### 4. Audio architecture
- Added `AudioManager` as the shared façade for narration and prototype SFX.
- Added authoritative master mute.
- `VoiceDirector` can now run without creating a second floating audio toggle (`showToggle: false`).
- `PrototypeAudio` now supports mute state.
- Legacy `askonauts-voice-muted` persistence remains synchronized for older scenes during migration.

### 5. Settings
- Added persistent `GameSettingsStore`.
- Added Settings overlay with:
  - Master Audio
  - Voice Narration
  - Sound Effects
  - Captions preference
  - Reduce Motion preference
  - Text Size preference
  - Reset Settings
  - protected two-step Reset Progress
  - Return to Clubhouse
- Music is explicitly shown as a future audio-production feature rather than pretending music exists today.

### 6. Dynamic UI cleanup
- Spoon Lab Current Discovery body now receives an opaque runtime surface before live copy is rendered.
- This prevents the runtime discovery copy from stacking directly over baked discovery body text.

## Compatibility / regression protection
- `VoiceDirector` retains its old visible-toggle behavior by default so non-Spoon scenes are not broken by this build.
- `PrototypeAudio` defaults to unmuted.
- Player progress schema is unchanged; only a public reset method was added.
- P6.4A-HF8 Spoon interaction geometry is preserved.

## Deliberately deferred to P6.4C
P6.4B proves the shared shell in Spoon Lab. P6.4C should replace the independent navigation implementations in Shadow Chase, Reflection Hunt, Funhouse Mirrors, and Clubhouse with the same shell and enforce accessibility preferences scene-wide.
