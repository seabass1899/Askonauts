# Changes

- Passes the Star Window center coordinates into `handleStarWindowTap(x, y)` from both click targets.
- Preserves shooting-star and hidden constellation behavior.
- No save-data, mission, progression, or visual-system changes.
