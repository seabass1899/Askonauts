# ASKONAUTS P5.6-HF2 — Clubhouse Reward-Zone Cleanup

## Changes
- Moves the Discovery Trophies display upward into a protected wall-mounted reward zone.
- Narrows and compacts the trophy shelf so it stays clear of Veya, Quip, Teyo, speech bubbles, and Teyo's table.
- Integrates `MASTER ASKONAUT CLUBHOUSE` into the trophy display footer when full mastery is reached.
- Removes the separate mastery banner that was being obscured by the character stage.
- Keeps trophy tap/recap behavior intact.
- Updates the Clubhouse build marker to `P5.6-HF2`.

## Unchanged
- Mission logic
- Mastery logic
- Sparks
- Save data
- Character positions/art
- Question Tree
- Journal
