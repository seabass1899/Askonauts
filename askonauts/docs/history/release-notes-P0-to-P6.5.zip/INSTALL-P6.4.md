# Install P6.4

1. Extract this ZIP over your current ASKONAUTS project root (P6.3-HF2 baseline).
2. Allow the included file to replace `src/game/scenes/ReflectionHuntScene.ts`.
3. Run:
   npm run build
4. Then run:
   npm run dev
5. Hard refresh the browser with Ctrl+F5 if the old scene is cached.
