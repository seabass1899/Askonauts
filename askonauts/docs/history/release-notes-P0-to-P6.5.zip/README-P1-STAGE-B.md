# ASKONAUTS P1.0 — Stage B Integration

This package layers the P1 mission engine onto the working P0.5.2b Shadow Box without changing the child-facing gameplay layout.

## What Stage B wires into MissionDirector

- Quip movement -> `object_moved(quip)`
- Lamp movement -> `object_moved(light)`
- Light ON/OFF -> `light_toggled`
- Live shadow visibility, scale and vertical position -> `shadow_observed`
- GIANT QUIP -> `secret_discovered(giant_quip)`

A drag is counted as a mission move only after the object has actually moved at least 8 px. Each drag emits at most one mission move signal, preventing pointer-event spam.

The shadow-change detector now recognizes both meaningful scale changes and meaningful vertical position changes. That means a child gets credit when a vertical drag visibly moves the shadow even if its size barely changes.

## P1 mission telemetry

The existing playtest telemetry remains intact and the raw summary now also records:

- current mission stage
- discovery ledger
- discovery timestamps
- stage reached/completed timestamps
- Curiosity Sparks
- hint keys reached
- free-experiment interaction count

These are stored in the existing `events` and `raw_summary` JSON fields, so no Supabase schema change is required for Stage B.

Build identifier: `P1.0B`

The telemetry API accepts P0.5.2, P0.5.2a, P0.5.2b and P1.0B so earlier test data remains compatible.

## Expected behavior in Stage B

The child-facing scene still looks like P0.5.2b. Stage B is plumbing, not the new mission presentation.

With the current mechanics, the mission can naturally progress through:

Mystery -> Shadow Follows -> Light Matters -> Lights Out -> Size Hunt

It then waits at `block_it`, because the blocker/rock is intentionally a Stage C mechanic and has not been added yet.

## Validation completed

- Mission engine strict TypeScript compile: PASS
- Stage B semantic smoke test: PASS
- Vertical-only Quip movement shadow-change test: PASS
- Expected progression to `block_it`: PASS
- Expected Curiosity Sparks through Size Hunt: 10
- P1.0B telemetry API acceptance/storage-shape smoke test: PASS
- Modified TypeScript syntax transpile check: PASS
- Mission telemetry strict type-check in isolation: PASS

A full Vite/Phaser production build should still be run in the existing local project after extraction (`npm run build`) because this packaging environment does not contain the project's installed Phaser/Vite node_modules.
