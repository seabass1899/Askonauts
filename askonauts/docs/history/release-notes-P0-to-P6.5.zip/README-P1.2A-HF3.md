# ASKONAUTS P1.2A-HF3 — Responsive Safe-Frame

This hotfix corrects the ultrawide cropping introduced by the HF2 ENVELOP pass.

## Composition architecture

- The authored 1280×720 gameplay scene now uses Phaser `FIT` scaling.
- Quip, lamp, blocker, Observation Screen, Question Compass and Parent UI therefore remain fully visible at every landscape aspect ratio.
- A separate DOM scenic layer fills any extra browser area behind the fitted canvas, so ultrawide screens do not fall back to plain dead bars.
- The scenic extension is deliberately blurred/dimmed; it is atmosphere, not another gameplay copy.

## Preserved

- optics math and shadow projection
- drag bounds and touch zones
- all mission stages and thresholds
- P1.2A-HF2 shadow cleanup
- telemetry schema and progression

## Build ID

`P1.2A-HF3`
