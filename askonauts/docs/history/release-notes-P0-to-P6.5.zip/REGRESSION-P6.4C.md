# P6.4C Regression Checklist

Run this once after `npm install` and `npm run dev`.

## Global shell — every world

For Shadow Chase, Reflection Hunt, Spoon Lab, Funhouse Mirrors, and Clubhouse:

1. Open Journal; verify it appears above the current world.
2. Close Journal; verify the world remains where it was.
3. Open Question Tree; verify it appears above the current world.
4. Close Tree; verify the world remains where it was.
5. Open Settings; change Master Audio; verify the header speaker state changes immediately.
6. Toggle Audio from the header; verify Settings reflects the same persisted state.
7. Leave audio muted, change worlds, and verify mute remains active.

## Navigation

- Shadow Chase: Clubhouse button returns home; ESC also returns home.
- Reflection Hunt: Clubhouse returns home; LIGHT RESCUE still starts correctly; ESC returns home.
- Spoon Lab: Clubhouse returns home; all spoon controls remain functional.
- Funhouse Mirrors: Clubhouse returns home; mirror controls remain functional; ESC returns home.
- Clubhouse: Journal/Tree/Settings/Audio work; no redundant Home control is shown.

## Audio

- Voice narration respects Master Audio and Voice Narration settings in every world.
- Shadow Chase SFX respect Master Audio and Sound Effects settings.
- Turning only Voice Narration off leaves Shadow Chase SFX available.
- Turning only Sound Effects off leaves narration available.

## Gameplay smoke tests

- Shadow Chase: drag lamp, Quip, and blocker; complete one discovery.
- Reflection Hunt: rotate/select a surface and start Light Rescue.
- Spoon Lab: move viewer, move distance, flip spoon, use one experiment tool.
- Funhouse Mirrors: switch through all mirror modes and start Mirror Mission.
- Clubhouse: open one world from the existing world/mission UI.

## Pass criterion

P6.4C is accepted when the shared shell works identically across all five scenes and no existing world-specific controls regress.
