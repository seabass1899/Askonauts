# P1.1A changes

- Added `LightLabEnvironment` presentation layer.
- Replaced prototype room rectangles with the Light Lab visual direction.
- Restyled the interactive lamp and blocker without moving their gameplay coordinates.
- Added dynamic ambient/screen warmth tied to the lamp state.
- Updated build telemetry identifier to `P1.1A`.
- Added `P1.1A` to the telemetry API allow-list.
