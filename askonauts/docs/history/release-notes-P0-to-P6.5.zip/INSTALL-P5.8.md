# Install — P5.8

Apply this overlay over the current P5.7 project.

Then run:

```bat
npm run build
npm run dev
```

Hard-refresh the browser if needed:

```text
Ctrl + F5
```

Recommended validation:
1. Replay Light Rescue several times and confirm the mission variant changes.
2. Replay Spoon Sprint and look for Surprise Order, Mixed Starts, or Two-Move Bonus.
3. Replay Mirror Mission and confirm direct prompts, riddles, and science clues can appear on different runs.
4. Confirm mission mastery and Curiosity Sparks do not increase from repeated mission replay.
