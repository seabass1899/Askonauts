# ASKONAUTS P5.1-HF2 — Readable Message Timing

This hotfix slows transient on-screen phrases so children have enough time to read them.

## Changes
- Clubhouse speech bubbles now use dynamic reading time based on word count.
- Reflection discovery messages remain visible longer.
- Reflection success/mission banners remain visible longer.
- Spoon Lab transient messages now use dynamic reading time.
- Funhouse Mirrors transient messages now use dynamic reading time.
- No gameplay, discovery, mission, save, Spark, or progression logic changed.

## Reading-time rules
- Clubhouse bubbles: minimum ~4.5s, up to 9s depending on length.
- Spoon/Funhouse transient messages: minimum ~3.8s, up to 8s depending on length.
- Reflection discovery messages: ~5.2s.
- Success/mission banners: ~3–3.8s.
