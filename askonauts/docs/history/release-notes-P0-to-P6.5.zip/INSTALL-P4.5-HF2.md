# Install — P4.5-HF2

Apply this overlay on top of your working **P4.5-HF1** project.

1. Close the dev server if it is running.
2. Extract the ZIP into the project root and allow the included files to replace their existing versions.
3. Run:

```bat
npm run build
npm run dev
```

Expected visible build marker in Spoon Lab:

`P4.5-HF2`

## Quick validation

- Viewer should have a fuller bust/upper-body silhouette.
- Convex reflection should remain upright/small with a subtle curved appearance.
- Concave far should be upside down and subtly vertically stretched.
- Concave near should be upright/larger and slightly wider.
- Reflection transitions should remain smooth.
- Spoon flip, challenges, secrets, and saved progress should behave exactly as before.
