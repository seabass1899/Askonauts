# P5.1-HF1 — Clubhouse Character Canon + Layout Fix

- Restores darker melanin-rich Veya and Teyo Clubhouse artwork using cache-busted asset names.
- Lowers and slightly reduces the trio so Discovery Wall / Mission Board copy remains readable.
- Moves name labels, speech bubbles, and idle tween targets with the new baseline.
- Updates Clubhouse build marker to P5.1-HF1.
- No mission, progression, Spark, Journal, or Question Tree logic changes.
