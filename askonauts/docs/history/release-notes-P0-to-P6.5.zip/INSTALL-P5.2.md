# Install P5.2

Apply this overlay over ASKONAUTS P5.1-HF2.

Then run:

```bat
npm run build
npm run dev
```

Expected visible markers:
- Clubhouse: P5.2
- Reflection Hunt: P5.2
- Spoon Lab: P5.2
- Funhouse Mirrors: P5.2

Recommended smoke test:
1. Open Mission Board and confirm GUIDE labels.
2. Start LIGHT RESCUE and confirm Veya/Teyo/Quip mission text.
3. Start SPOON SPRINT and confirm rotating character prompts.
4. Start MIRROR MISSION, intentionally choose one wrong mirror, then a correct one.
5. Confirm Sparks and completed-world state are unchanged by mission replay.
