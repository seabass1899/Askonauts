# ASKONAUTS P5.3 — Better Success / Failure Loops

P5.3 strengthens mission gameplay across Reflection Hunt, Spoon Lab, and Funhouse Mirrors.

## Reflection Hunt — LIGHT RESCUE
- Near-miss detection when the reflected beam comes close to the target.
- "SO CLOSE" feedback and target pulse.
- After repeated attempts, Teyo gives a non-spoiling steering hint.
- Mission attempt state resets for each target.

## Spoon Lab — SPOON SPRINT
- Mission actions are tracked per objective.
- After repeated unsuccessful actions, the appropriate crew member gives a contextual hint.
- Hints are tailored to FLIP IT, MAKE IT HUGE, and SHRINK IT.
- No penalty or Spark loss for experimentation.

## Funhouse Mirrors — MIRROR MISSION
- Wrong predictions now produce contextual visual clues about the target effect.
- First miss is framed as GOOD TRY; subsequent miss becomes a stronger CLUE.
- Reflection gets a brief shake response on incorrect predictions.
- Correct predictions get stronger TEST CONFIRMED feedback.

## Philosophy
The child should feel: try -> observe -> adjust -> solve -> celebrate.
No lives, timers, punishment, or grinding were added.

Quip character art is intentionally not modified in P5.3.
