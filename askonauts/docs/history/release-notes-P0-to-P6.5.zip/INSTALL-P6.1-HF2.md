# Install P6.1-HF2

Overlay this package onto the current ASKONAUTS project after P6.1-HF1.

Then run:

npm run build
npm run dev

Hard refresh with Ctrl+F5 if the old background is cached.
