# Install P4.5-HF1

Apply this overlay over your working **P4.5** project.

Files added/replaced:
- `src/game/components/ViewerFace.ts` (new)
- `src/game/scenes/UpsideDownSpoonScene.ts`
- `src/game/scenes/ClubhouseScene.ts`
- `package.json`

Then run:

```bat
npm run build
npm run dev
```

Visible verification:
- Clubhouse header: `P4.5-HF1`
- Spoon Lab header: `P4.5-HF1`

Recommended test:
1. Open Spoon Lab.
2. Tap FLIP SPOON and confirm the spoon visibly flips before the reflection changes.
3. Rapid-tap FLIP SPOON; state should not break.
4. Move FAR/MIDDLE/NEAR and confirm viewer glides along the rail.
5. Verify the reflected face matches the viewer and visibly changes size/orientation.
6. Re-run Flip It / Make It Huge / Shrink It challenges.
7. Refresh and confirm existing progress remains unchanged.
