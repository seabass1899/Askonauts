# Install P5.0

Apply this overlay on top of the current working build that already includes P4.6-HF3 and P4.6-HF4.

Then run:

```bat
npm run build
npm run dev
```

Validate:
1. Reflection Hunt: LIGHT RESCUE appears in the header and unlocks after world completion.
2. Spoon Lab: SPOON SPRINT appears in the header and unlocks after world completion.
3. Funhouse Mirrors: Mirror Mission runs four randomized prediction rounds.
4. Existing discoveries, Sparks, Journal, Question Tree, and Clubhouse navigation remain unchanged.
