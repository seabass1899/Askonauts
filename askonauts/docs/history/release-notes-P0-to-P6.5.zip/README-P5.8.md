# ASKONAUTS P5.8 — Randomized Mission Variants

P5.8 increases replayability without changing the underlying science or progression systems.

## Reflection Hunt — Light Rescue variants
Each run now chooses one of three mission variants:
- **Surprise Order** — targets are shuffled.
- **Shifting Start** — each target begins from a different mirror angle.
- **Precision Rescue** — the target starts slightly tighter, then quietly relaxes after several attempts so difficulty never becomes punitive.

## Spoon Lab — Spoon Sprint variants
Each run now chooses one of three variants:
- **Surprise Order** — the three objectives are shuffled.
- **Mixed Starts** — each objective begins from a different spoon-side/distance setup.
- **Two-Move Bonus** — objectives remain fully solvable normally, with an optional bonus callout for solving a step in two moves or fewer.

The two-move bonus is presentation only. It does not gate mastery or award farmable Sparks.

## Funhouse Mirrors — Mirror Mission variants
Each run now chooses one of three prompt styles:
- **Prediction Mode** — direct effect prediction.
- **Riddle Mode** — playful descriptive riddles.
- **Science Clue Mode** — prompts describe how curvature changes the image.

Mirror order is still randomized each run.

## Clubhouse
Mission Board descriptions now explain that these missions can change from run to run.

## Preserved
- existing saves and Sparks
- mission mastery IDs
- world completion
- character audio personality
- P5.6 Clubhouse progression systems

Known visual debt remains intentionally deferred:
- canonical Quip Clubhouse art
- final Clubhouse reward/trophy layout
