# P1.2D — Question Gate Cinematic

This pass replaces the menu-first Question Gate payoff with an in-world cinematic sequence.

## Changes

- LIGHT / BLOCK / SHADOW evidence tokens converge into a temporary Compass core.
- Compass energy travels across the Light Lab and assembles the Question Gate.
- The Gate forms in-world with rotating brass/violet rings, energy glow, and a live Reflection Hunt teaser.
- The teaser contains reflective panels, a spoon cue, and a mirrored Quip glimpse.
- The portal itself is the primary ENTER control (`TAP THE GATE`).
- EXPLORE MORE remains available without leaving the current session.
- Entering the Gate performs a camera push, portal charge, and transition into the Reflection Hunt teaser state.
- BACK TO LAB returns the child to exploration and leaves a persistent Gate marker.
- Existing Question Gate telemetry events and MissionDirector progression are preserved.
- Build id updated to `P1.2D`.

No Supabase schema change is required.
