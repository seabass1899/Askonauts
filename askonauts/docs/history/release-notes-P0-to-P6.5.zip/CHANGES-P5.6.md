# Changes — P5.6

## Clubhouse evolution
- Clubhouse marker updated to P5.6.
- Added a four-slot Discovery Trophy shelf.
  - Shadow Chase trophy unlocks when Shadow Chase is complete.
  - Reflection Hunt trophy unlocks when Reflection Hunt is complete.
  - Upside-Down Spoon trophy unlocks when Spoon Lab is complete.
  - Funhouse Mirrors trophy unlocks when Funhouse Mirrors is complete.
- Unlocked trophies pulse subtly and can be tapped for a short discovery recap.
- Locked trophies remain visible as mystery silhouettes.

## Spark Vessel evolution
- Vessel label now reflects progression: WARMING / AWAKE / GLOWING / RADIANT.
- Higher Spark totals add environmental glow and orbiting motes.
- Full mission mastery adds a mastery star above the vessel.

## Rank imprint
- The Clubhouse rug gains visible rank stars as the child advances through Askonaut mastery tiers.
- Master Askonaut status adds a small MASTER ASKONAUT CLUBHOUSE plaque.

## Quip
- No Quip sprite or framing changes in this phase.
- Canonical Quip Clubhouse art remains on the visual-debt list for a later dedicated asset pass.
