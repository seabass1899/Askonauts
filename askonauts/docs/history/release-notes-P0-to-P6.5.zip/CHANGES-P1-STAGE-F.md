# P1.0F changes

- Added child-facing Question Gate with awakening, choice, Explore More, persistent reopen marker, entry animation, and Reflection Hunt teaser.
- Added final `question_gate_entered` mission completion path to the existing mission loop.
- Added Stage F telemetry and timing fields without changing the Supabase schema.
- Replaced the legacy parent-panel continued-experimenting line with actual P1 Gate metrics.
- Added Gate metrics and CSV fields to the protected admin dashboard.
- Added synthesized Gate wake/entry prototype audio.
- Build identifier is now `P1.0F`.
