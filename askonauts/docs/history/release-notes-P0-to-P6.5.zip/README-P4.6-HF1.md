# ASKONAUTS P4.6-HF1 — Mirror Labels + Question Tree Layout

This hotfix corrects the Funhouse Mirrors presentation without changing progression or discovery logic.

## Changes
- Mirror label now updates for each selected mirror mode:
  - FLAT MIRROR
  - VERTICALLY CURVED MIRROR
  - HORIZONTALLY CURVED MIRROR
  - MIXED-CURVE MIRROR
- FLAT mirror frame now uses nearly straight corners instead of the strongly rounded curved-frame treatment.
- Question Tree right branch repositioned so Reflection Hunt, Upside-Down Spoon, and Funhouse Mirrors no longer overlap.
- Question Tree guidance panel moved lower-left to leave room for the growing reflection branch.
- Visible build marker updated to P4.6-HF1.

No save IDs, discovery IDs, Sparks, completion rules, or world navigation logic changed.
