# ASKONAUTS P1.3C-HF1 — Question Gate Composition Fix

Apply this hotfix over the working P1.3C project.

## What changed

- Reworked the completed Question Gate into a two-zone layout.
- Left side: opened Question Gate remains the hero visual.
- Right side: dedicated completion panel contains completion status, Reflection Hunt teaser, and actions.
- Compass and evidence-token visuals are removed once the Gate reaches completion.
- Increased cinematic backdrop dimming so Light Lab props remain context instead of competing with the finale.
- Moved PLAY AGAIN and BACK TO LAB into the completion panel.
- No mission progression, light physics, hint, voice, telemetry, or Gate-awakening logic changed.

## Install

Extract over the current P1.3C project root and replace files.

Then run:

    npm run build
    npm run dev

## Files

- src/game/objects/QuestionGate.ts
