# P0.5.2 Changes

## Parent simplicity
- one-link parent setup
- age-band buttons
- explicit telemetry consent
- visible Parent button
- no mandatory file downloads
- four tap-only finish questions

## Telemetry reliability
- same-origin Vercel telemetry endpoint
- Supabase server-side storage
- debounced automatic sync after gameplay events
- 10-second snapshot heartbeat
- local pending queue on network failure
- online retry
- pagehide/visibility beacon
- in-progress sessions retained even if Finish Test is skipped

## Research workflow
- source/tester query labels
- password-protected owner results endpoint
- `/admin.html` aggregate dashboard
- CSV export
