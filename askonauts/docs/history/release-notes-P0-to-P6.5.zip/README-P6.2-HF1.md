# ASKONAUTS P6.2-HF1 — Star Window Build Fix

Apply over P6.2.

Fixes the strict TypeScript error caused by calling `handleStarWindowTap()` without the required window coordinates.

No gameplay or UI behavior changes beyond restoring the intended Star Window interaction.
