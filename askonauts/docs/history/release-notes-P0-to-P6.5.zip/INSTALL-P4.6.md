# Install P4.6

Apply this ZIP over the current **P4.5-HF2-FIX3** working project.

Then run:

```bat
npm run build
npm run dev
```

Expected path:

`Clubhouse -> Question Compass -> FUNHOUSE MIRRORS -> Mirror Hall`

Existing save data should remain intact.
