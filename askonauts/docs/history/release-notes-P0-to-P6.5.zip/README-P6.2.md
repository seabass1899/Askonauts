# ASKONAUTS P6.2 — Live UI Harmonization + Modal Overhaul

P6.2 harmonizes the live Phaser UI with the illustrated P6.1-HF2 Clubhouse environment.

## Highlights
- Removes duplicate Phaser-drawn physical objects where the illustrated room already supplies them.
- Keeps Star Window, Question Compass, Question Gate, Spark Vessel, and Teyo's workbench interactive through live hotspots/state overlays.
- Reduces opaque UI blocks so more of the illustrated clubhouse remains visible.
- Repositions and restyles Discovery Wall, Mission Board, and trophy dock for a cleaner hierarchy.
- Softens overlay dimming and updates Journal / Question Tree / Mission Board panels to better match the premium visual system.
- Preserves all gameplay, progression, mastery, Sparks, save data, and P5.9 dynamic mission behavior.

## Visual debt intentionally deferred
- Full world-by-world UI makeover (Shadow Chase, Reflection Lab, Spoon Lab, Funhouse Mirrors) belongs to P6.3.
- Additional motion/transitions belong to P6.4.
