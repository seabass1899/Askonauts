# ASKONAUTS P5.2-HF2 — Quip + Mirror Mission Control Fix

Apply over P5.2-HF1 / rollback baseline.

Changes:
- Clubhouse uses a complete-ear Quip asset; removes all synthetic ear geometry.
- Funhouse Mirror Mission button is only shown when mission is idle.
- When mission is active, START MISSION is hidden and the panel says MISSION ACTIVE.
- After completion, the button returns as PLAY AGAIN.
- Build markers updated to P5.2-HF2.

Run:
  npm run build
  npm run dev

Then hard refresh with Ctrl+F5.
