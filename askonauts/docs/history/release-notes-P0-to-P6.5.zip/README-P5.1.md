# ASKONAUTS P5.1 — Mission System Integration

Adds a Clubhouse Mission Board and direct mission launch for the current playable worlds.

## Included
- Clubhouse Mission Board with four mission cards
- LIGHT RESCUE launches directly into mission mode
- SPOON SPRINT launches directly into mission mode
- MIRROR MISSION launches directly into mission mode
- SHADOW QUEST routes back to Shadow Chase with a mission replay prompt
- Mission-complete celebration banners in Reflection, Spoon, and Funhouse worlds
- P5.1 build markers

No saved discovery IDs, Spark values, Question Tree progression, identity, or age-band data are changed.
