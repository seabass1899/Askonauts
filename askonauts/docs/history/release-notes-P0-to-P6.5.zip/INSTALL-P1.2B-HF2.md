# Install P1.2B-HF2

Extract this archive into the ASKONAUTS project root and choose **Replace files in destination**.

Do not remove `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
```

If clean:

```bat
npm run dev
```

Verify the title reads `SHADOW CHASE • P1.2B-HF2`. Test Telescope, Prism, Question Jar and Brass Dial and confirm each still reacts normally while appearing physically grounded on the lab bench.
