# ASKONAUTS P1.3C-HF2 — Voice Arbitration Fix

Apply over P1.3C-HF1.

## Fixes
- Prevents the Block It stage reaction from speaking over the Evidence Lock explanation.
- Keeps the visual Quip reaction for the rock discovery.
- Adds priority/exclusive arbitration to VoiceDirector.
- Evidence narration runs as high-priority exclusive speech, so ordinary hints and stage reactions cannot interrupt it.
- Stale browser TTS completion events can no longer clear the state of a newer utterance.

## Expected rock sequence
1. Rock enters the light and creates a shadow.
2. Quip can react visually: `THE ROCK MADE ONE TOO!`
3. After the observation beat, Quip says the complete evidence line once.
4. No second voice line interrupts it.
5. After Quip finishes, the Question Compass opens.

Run:

    npm run build
    npm run dev
