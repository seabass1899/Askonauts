# P5.1 Changes

- Added Clubhouse Mission Board.
- Added direct mission scene-start data for Reflection, Spoon, and Funhouse worlds.
- Ensured LIGHT RESCUE has a visible P5.1 entry point and can auto-start from the Mission Board.
- Added short mission-complete celebration banners.
- Updated visible world/build markers to P5.1.
