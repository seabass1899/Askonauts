# ASKONAUTS P4.0-HF1 — Derived Discovery Revisit

This hotfix makes the completed **Shadow Size** node in the Question Tree directly usable.

## Changes
- Clubhouse build marker updates to **P4.0-HF1**.
- Tapping completed **SHADOW SIZE** opens a discovery detail panel.
- The panel explains why shadow size changes.
- **TRY IT AGAIN** returns to Shadow Chase with the size experiment as the replay focus.
- **BACK TO TREE** returns to the Question Tree.
- Shadow Size remains a derived discovery, not a separate Discovery World.

## Install
Apply this overlay over **P4.0** and replace the included file.

Then run:

```bat
npm run build
npm run dev
```

## Replaced file
- `src/game/scenes/ClubhouseScene.ts`
