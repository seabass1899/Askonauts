# P6.5 Cross-World Regression Checklist

## Global shell
- [ ] Journal icon + label are visible and open the Journal.
- [ ] Tree icon + label are visible and open the Question Tree.
- [ ] Settings icon + label are visible and open Settings.
- [ ] Audio icon changes state when master mute is toggled.
- [ ] HOME returns to the Clubhouse from all experiment worlds.
- [ ] Escape closes the active overlay before navigating away.
- [ ] No global utility button is clipped at the right edge.

## Settings
- [ ] Master Audio persists between worlds.
- [ ] Voice Narration persists between worlds.
- [ ] Sound Effects persists between worlds.
- [ ] REDUCE MOTION persists after refresh.
- [ ] With REDUCE MOTION on, Shadow Chase cinematic pulses/FX are visibly reduced.

## World smoke tests
- [ ] Shadow Chase: lamp, Quip, blocker, shadow scale, Compass, Gate, completion.
- [ ] Reflection Lab: Mirror / Spoon / Rough Panel, rotate, flip, Light Rescue.
- [ ] Spoon Lab: movement, distance, flip, discoveries, Journal/Tree/Settings/Audio/Clubhouse.
- [ ] Funhouse Mirrors: Flat / Tall / Wide / Wavy, preview deformation, Mirror Mission.
- [ ] Clubhouse: identity, mission board, Question Tree, Journal, Sparks, world routing.

## Persistence
- [ ] Sparks unchanged after scene transitions.
- [ ] discoveries/secrets remain recorded.
- [ ] last-world routing remains correct.
- [ ] no progress resets unless explicitly confirmed in Settings.
