# Install P3.0

Base: working ASKONAUTS P2.3 project (including the earlier P2.2-HF1 / P2.1 identity fixes already present locally).

1. Back up the current project.
2. Extract this ZIP directly over the project root.
3. Allow the files in `src/` and `package.json` to replace existing versions.
4. Run:

```bat
npm run build
```

5. If successful:

```bat
npm run dev
```

## First validation
1. Clubhouse header should show **P3.0**.
2. Open the Question Tree. Reflection Hunt should be **READY TO EXPLORE** if Shadow Chase is complete.
3. Either double-tap/click Reflection Hunt in the tree or tap the Reflection Question Gate.
4. Reflection Lab should open.
5. Select MIRROR, ROUGH PANEL, and SPOON.
6. Rotate the mirror.
7. Find the PERFECT BOUNCE target if desired.
8. Complete all four core discoveries.
9. Return to Clubhouse.
10. Question Tree should show Reflection Hunt **COMPLETED** and reveal **UPSIDE-DOWN SPOON**.
11. Discovery Journal should contain Reflection Hunt discoveries.
