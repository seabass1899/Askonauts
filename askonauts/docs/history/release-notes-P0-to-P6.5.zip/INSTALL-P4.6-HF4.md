# Install

Apply this overlay over the current ASKONAUTS project after P4.6-HF3.

Then run:

```bat
npm run build
npm run dev
```

Test Reflection Hunt by rotating the mirror several times. The ANGLE MATTERS line should speak only on its first discovery.
