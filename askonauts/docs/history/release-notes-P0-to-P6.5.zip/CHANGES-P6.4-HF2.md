# P6.4-HF2 Changes

## Shadow Chase navigation
- Added always-available CLUBHOUSE control at depth 5000.
- Added Escape keyboard shortcut.
- Centralized exit behavior in returnToClubhouse().
- Existing Question Gate Return to Clubhouse action now uses the same safe exit path.
- Repositioned Parent button to avoid overlap.
