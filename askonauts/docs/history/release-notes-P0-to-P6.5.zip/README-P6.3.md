# ASKONAUTS P6.3 — Canonical Clubhouse Reconstruction

This overlay rebuilds the live Clubhouse around the approved makeover composition rather than the earlier flat Phaser card layout.

## Highlights
- Canonical Discovery Wall skin and live Journal hotspot
- Canonical Question Compass centerpiece with live question count
- Canonical Mission Board skin linked to the existing dynamic mission modal
- Canonical Question Gate presentation with existing progression logic preserved
- Canonical Discovery Trophy panel with live trophy interactions
- Canonical Spark Vessel with live Spark count/state overlay
- Existing illustrated observatory environment retained
- Veya, Quip, Teyo, mastery, identity, Sparks, missions, persistence, Journal and Question Tree logic preserved

Apply over P6.2-HF1.
