# ASKONAUTS P3.2-HF2 — Reflection Lab Layout & Discovery Tracker Cleanup

Apply this overlay on top of **P3.2-HF1**.

## Changes
- Moves **TEST A SURFACE** to the lower-left control rail so it no longer obscures the light source or incoming beam.
- Replaces the four ambiguous back-wall placeholder boxes with a live **REFLECTION CLUES** tracker:
  - MIRROR — SMOOTH
  - ROUGH — SCATTERS
  - ANGLE — STEERS
  - CURVE — CHANGES IMAGE
- Completed clues show a green check state.
- Incomplete clues remain muted and read **FIND THIS CLUE**.
- Tracker state is derived from existing Reflection Hunt discoveries; no duplicate progression state is introduced.
- Updates the Reflection Lab build marker to **P3.2-HF2**.

## Unchanged
No reflection math, challenge targets, Curiosity Sparks, persistence, navigation, Question Tree, Journal, player identity, or age-band logic was changed.

## Install
Extract over the project root and replace the file, then run:

```bat
npm run build
npm run dev
```

Expected file replaced:

`src/game/scenes/ReflectionHuntScene.ts`
