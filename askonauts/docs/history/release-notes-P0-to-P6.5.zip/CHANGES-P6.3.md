# P6.3 Changes

- Replaced several flat Clubhouse UI blocks with visual skins derived from the approved canonical makeover.
- Added live interaction overlays so visual richness does not remove dynamic navigation.
- Live Spark total/state remains authoritative.
- Live Shadow Chase discovery/secret count remains authoritative.
- Question Compass count remains dynamic.
- Mission Board continues to open the existing randomized mission system.
- Question Gate progression behavior is preserved.
- Trophy interactions remain live.
- No save schema or mission logic changes.
