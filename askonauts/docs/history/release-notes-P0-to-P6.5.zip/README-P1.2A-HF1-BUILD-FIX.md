# ASKONAUTS P1.2A-HF1 Build Fix

Fixes TypeScript TS6138 in `LightLabEnvironment.ts` by keeping the existing constructor call shape while making `wallX` an intentionally unused compatibility parameter rather than an unused private class field.

No gameplay, visuals, physics, telemetry, or mission logic are changed.

Install over P1.2A-HF1 and run `npm run build` again.
