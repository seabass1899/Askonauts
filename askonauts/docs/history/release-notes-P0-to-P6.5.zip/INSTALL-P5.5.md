# Install P5.5

Apply this overlay over the current P5.4 build.

Then run:

```bat
npm run build
npm run dev
```

Existing discovery and Spark progress is preserved. Mastery uses a separate `askonauts.mastery.v1` localStorage record.
