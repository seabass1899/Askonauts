# Install P4.0

Base: **P3.2-HF2**

1. Back up the current project.
2. Extract the P4.0 ZIP over the project root and replace files.
3. Run:

```bat
npm run build
npm run dev
```

## First validation
1. Confirm the Clubhouse/Question Tree exposes **UPSIDE-DOWN SPOON** after Reflection Hunt is complete.
2. Enter the Spoon Lab.
3. Test both spoon sides.
4. Move closer and farther.
5. Confirm the reflection visibly changes orientation and size.
6. Collect all four Spoon Clues.
7. Cross the concave near/middle boundary and confirm the **FLIP POINT** secret.
8. Complete the world and return to the Clubhouse.
9. Confirm **FUNHOUSE MIRRORS** appears as the next question.
10. Open the Discovery Journal and confirm Spoon Lab entries appear.
