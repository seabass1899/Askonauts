# Install P5.9

Apply this overlay over the current P5.8 project.

Then run:

```bat
npm run build
npm run dev
```

Recommended playtest: replay Light Rescue, Spoon Sprint, and Mirror Mission at least 3 times each and verify that objective count/order, setup, prompts, or constraints vary between runs.
