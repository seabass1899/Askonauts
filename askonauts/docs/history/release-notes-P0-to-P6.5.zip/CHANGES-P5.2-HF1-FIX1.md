# Changes

- Removed the small triangular ear-tip workaround.
- Added full stylized gold/purple ear extensions behind Quip so the ears no longer read as clipped.
- No gameplay or progression changes.
