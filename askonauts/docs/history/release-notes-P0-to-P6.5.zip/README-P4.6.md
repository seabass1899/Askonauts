# ASKONAUTS P4.6 — Funhouse Mirrors

Adds the fourth Discovery World: **Funhouse Mirrors**.

Core question: **Why do funhouse mirrors stretch and squash us?**

The world reuses the stabilized ViewerFace/reflection system from Spoon Lab and introduces four mirror behaviors:

- Flat — same proportions
- Tall — stretched vertically
- Wide — squashed vertically / widened horizontally
- Wavy — mixed curvature warps the reflection

Four discoveries complete the world. Testing all four also reveals the **Mirror Morph Master** secret.

This package also wires Funhouse Mirrors into the Question Tree, World Registry, Discovery Journal, Clubhouse navigation, and scene registration.
