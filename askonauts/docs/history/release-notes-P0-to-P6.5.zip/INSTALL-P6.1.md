# Install P6.1

Apply this overlay over the current ASKONAUTS P6.0A project.

Then run:

```bat
npm run build
npm run dev
```

Hard-refresh the browser after the development server restarts:

```text
Ctrl + F5
```

P6.1 does not intentionally alter existing localStorage progress or mastery data.
