# ASKONAUTS P2.0 — Clubhouse Environment & Interaction Foundation

P2.0 turns the P1.4 Clubhouse shell into the first playable home world for ASKONAUTS Question World.

## Product intent

The Clubhouse is no longer a level-selection dashboard. It is a persistent place the child returns to between Discovery Worlds.

## What changed

- Rebuilt `ClubhouseScene` as a warm interactive observatory/workshop environment.
- Added canonical Veya and Teyo character art derived from the ASKONAUTS brand guide.
- Reused the existing in-game Quip art.
- Added a physical, tappable Question Compass.
- Added a physical Question Gate that launches Shadow Chase before completion and teases Reflection Hunt afterward.
- Added a Discovery Wall that visibly changes as Shadow Chase progress is saved.
- Added a visible Curiosity Spark Vessel driven by persisted Spark totals.
- Added Teyo's invention table as an interactive environmental hotspot.
- Added a tappable star window with a hidden shooting-star reaction.
- Added character-specific tap reactions for Veya, Teyo, and Quip.
- Added gentle character, Compass, Gate, star, lamp, and Spark idle motion.
- Added delayed hotspot affordances so children are invited to tap without turning the Clubhouse into a menu.
- Preserved the P1.4 `WorldRegistry` / `PlayerProgressStore` architecture.
- Shadow Chase remains the playable world; Reflection Hunt remains the next locked/coming-soon world.
- Telemetry build identifier updated to `P2.0`.

## Navigation

Before Shadow Chase completion:

`Clubhouse -> Question Compass / Question Gate -> Shadow Chase -> Question Gate -> Clubhouse`

After Shadow Chase completion:

- the Discovery Wall holds the Shadow Chase plaque,
- tapping the plaque revisits the Light Lab,
- the Question Compass reveals Reflection Hunt,
- the Question Gate visually changes to a forming Reflection Gate.

## P2.0 design rule

The Clubhouse should communicate progression through the room itself. It should not become a grid of level cards.

## Not in this build yet

- free-roaming player avatar
- ASKONAUT name/avatar onboarding
- full Discovery Journal
- Question Tree navigation
- dedicated final Clubhouse background illustration
- Reflection Hunt gameplay
- parent dashboard changes
- subscriptions/accounts

Those are subsequent product layers, not prerequisites for proving the home-world loop.
