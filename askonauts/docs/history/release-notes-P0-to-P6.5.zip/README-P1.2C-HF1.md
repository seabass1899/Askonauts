# ASKONAUTS Shadow Chase — P1.2C-HF1

Targeted production-art hotfix for the Block It stage.

The blocker now uses the detailed ASKONAUTS boulder asset rather than the prototype polygon. Its gameplay behavior is unchanged, but its visual presentation and projected shadow now match the production art direction.
