# P1.2C — Cinematic Discovery System

- Adds a short cinematic focus beat for meaningful discoveries.
- Adds subtle camera push/pan that always returns to the safe-frame center.
- Sends curved evidence Sparks from the discovery into the in-world Question Compass.
- Gives the Compass a visible core/needle response when evidence arrives.
- Smooths challenge handoffs with a room-light sweep and brief NEXT beat.
- Temporarily lowers the current objective HUD during transitions, then reveals the new objective.
- Adds a short cinematic evidence-capture sound.
- Adds `cinematic_discovery:*` entries through the existing delight telemetry stream.
- Build ID: `P1.2C`.

No mission thresholds, optics math, drag bounds, prop interactions, secrets, or Supabase schema changed.
