# Install P6.4A-HF7

Apply this overlay over P6.4A-HF6-FIX1.

Then run:

npm run build
npm run dev

Hard refresh the browser with Ctrl+F5.

Expected runtime marker: LIVE • P6.4A-HF7
