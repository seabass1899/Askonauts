# P0.5.2 Validation

## Completed in build environment

- all TypeScript source files were syntax/transpile checked
- Vercel API JavaScript endpoints passed Node syntax checks
- project archive structure verified
- telemetry schema and environment-variable wiring reviewed
- P0.5.1 gameplay code preserved except for playtest/telemetry UI integration

## Runtime checks to perform after deployment

1. Parent setup requires age band + consent before Start is enabled.
2. Game begins normally after Start.
3. Quip, light, ON/OFF, shadows, sound, and GIANT QUIP still work.
4. PARENT button pauses play and opens parent view.
5. Parent view shows `Saved automatically` after the API is configured.
6. Finish Test submits feedback and shows Playtest Saved.
7. Closing a session without Finish still produces an in-progress row in Supabase.
8. `/admin.html` accepts only the configured admin key.
9. Admin dashboard lists sessions and exports CSV.
10. Temporarily disabling connectivity produces a pending/offline state and the session uploads after connectivity returns.

## Environment limitation

The build environment could not complete an npm registry install, so final Phaser/Vite production execution should be verified by Vercel deployment, as with prior P0 builds.
