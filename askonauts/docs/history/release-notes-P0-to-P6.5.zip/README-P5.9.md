# ASKONAUTS P5.9 — Dynamic Mission Combination Engine

P5.9 makes variability systemic. Replay missions are no longer selected from one mutually exclusive mode; each run is assembled from multiple independent variables.

## Dynamic mission recipes

### Light Rescue
A run can combine:
- 2 or 3 target objectives
- randomized target order
- randomized mirror starting angles
- precision targeting
- optional 3- or 4-turn bonus goals

### Spoon Sprint
A run can combine:
- 2 or 3 reflection objectives
- randomized objective order
- known or mixed starting states
- direct or riddle-style prompts
- optional 2- or 3-move bonus goals

### Mirror Mission
A run can combine:
- 3 or 4 mirror objectives
- randomized target order
- prediction, riddle, or science-clue prompts
- fast or delayed hint reveal after incorrect predictions

## Design intent
The player should recognize the science but not know the exact mission recipe in advance. Replays reward understanding and adaptation rather than memorizing a fixed sequence.

No additional grind currency, lives, or punitive failure mechanics are added.

## Existing visual-debt reminders
- Revisit Quip's canonical Clubhouse art.
- Revisit final Clubhouse trophy/reward-zone layout.
