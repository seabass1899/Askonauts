# P6.4A-HF7 Changes

- Corrected left-side button hitbox centers and dimensions.
- Corrected right-side Experiment Tools hitbox centers and dimensions.
- Added rounded hover/press feedback with 18px radius for side-panel buttons.
- Preserved bottom control mapping and all experiment logic.
- Updated runtime marker to P6.4A-HF7.
