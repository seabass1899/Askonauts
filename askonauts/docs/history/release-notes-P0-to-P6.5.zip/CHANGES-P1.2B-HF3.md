# P1.2B-HF3 Changes

- Upgraded Telescope activation with lens flash, physical scan motion, scan beam, reticle, and constellation handoff.
- Upgraded Prism activation with bounce/tilt, amplified rainbow spill, and spectral particle burst.
- Upgraded Question Jar activation with shake/bounce, luminous spill, and animated question-mark release.
- Changed Brass Dial so the instrument face rotates independently of its grounded pedestal.
- Added concentric lab-energy waves and phase-colored room pulses to Brass Dial activation.
- Added subtle hover emphasis to production props without changing their hit zones.
- Expanded synthesized SFX for Telescope, Prism, Question Jar, and Brass Dial.
- Updated title, telemetry build identifier, package version, and telemetry API allowlist to `P1.2B-HF3`.
- No mission thresholds, optics math, Supabase schema, secret requirements, or drag mechanics changed.
