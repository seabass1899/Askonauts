# ASKONAUTS P2.0-HF1-V2 — Clubhouse Character Canon Correction

This replaces the ineffective first HF1 character pass.

## What changed
- Veya and Teyo now use new cache-busting asset names.
- Their skin tones are visibly darker/warmer to better match the episode-era ASKONAUTS direction.
- Veya scale increased from 0.60 to 0.90.
- Teyo scale increased from 0.58 to 0.88.
- Quip reduced from 0.54 to 0.50 so the trio reads as an ensemble.
- Veya/Teyo positions and labels were rebalanced.
- Teyo stray extraction text/artifact was removed.
- Clubhouse marker reads P2.0-HF1-V2.

No progression, Gate, Spark, Discovery Wall, or Shadow Chase logic was changed.
