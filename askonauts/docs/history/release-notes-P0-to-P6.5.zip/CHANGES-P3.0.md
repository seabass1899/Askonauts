# P3.0 Changes

- Added `ReflectionHuntScene`.
- Registered Reflection Hunt as a playable world.
- Added persistent generic world discovery / secret / completion helpers.
- Preserved optional age-band profile data during player-progress load/save.
- Added Reflection Hunt Question Gate routing from Clubhouse.
- Added Reflection Hunt launch from Question Tree.
- Added Reflection Hunt discoveries and secret to Discovery Journal.
- Added world-aware TRY IT AGAIN routing.
- Reflection completion now reveals the Upside-Down Spoon question.
- Updated package version to `3.0.0-reflection-hunt`.
