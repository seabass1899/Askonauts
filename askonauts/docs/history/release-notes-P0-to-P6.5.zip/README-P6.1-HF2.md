# ASKONAUTS P6.1-HF2 — Illustrated Clubhouse Integration

This hotfix replaces the flat programmatic room shell with a rich illustrated observatory environment while keeping the dynamic Phaser UI, progression, missions, characters, Journal, Question Tree, and save data live.

Apply over P6.1-HF1.
