# P5.5 Changes

- Added `MasteryProgress` local persistence.
- Added four mission mastery milestones.
- Added Explorer / Investigator / Discoverer / Master Askonaut ranks.
- Added Clubhouse mastery badge.
- Added Mission Board mastery bar and MASTERED / REPLAY state.
- Added persistent completion tracking for Light Rescue, Spoon Sprint, and Mirror Mission.
- Shadow Quest mastery syncs from meaningful Shadow Chase progress.
- Added readable Clubhouse rank-up celebration.
- No XP farming, lives, penalties, or Spark changes.
