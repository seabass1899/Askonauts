# P4.6-HF1 Changes

## Funhouse Mirrors
- Fixed static `CURVED MIRROR` label.
- Added dynamic mode-specific mirror labeling.
- Made FLAT mirror frame visually flatter.

## Question Tree
- Repositioned reflection branch nodes.
- Removed overlap between Spoon and Funhouse cards.
- Moved detail panel to lower-left to protect right-branch space.

## Compatibility
Presentation-only hotfix. Existing progress remains valid.
