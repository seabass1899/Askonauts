# Install P3.2

1. Back up the working P3.1-HF2 project.
2. Extract this ZIP over the project root and replace files.
3. Run:

```bat
npm run build
npm run dev
```

4. Confirm the Clubhouse and Reflection Lab show **P3.2**.
