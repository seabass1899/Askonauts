# Install P1.2C

Extract this archive directly over the existing P1.2B-HF5 project root and choose **Replace files in destination**.

Then run:

```bat
npm run build
npm run dev
```

The title should show `SHADOW CHASE • P1.2C`.
