# ASKONAUTS P1.2B-HF1 — Production Prop Art Integration

This hotfix upgrades the four optional Light Lab interactables from procedural placeholder graphics to production art assets while preserving the P1.2B interaction logic.

## Upgraded props
- Telescope — brass/indigo body, blue lens glow, gentle idle motion.
- Prism — crystalline rainbow material, sparkles, existing rainbow reveal retained.
- Question Jar — glass/brass hero object with animated motes and shake response.
- Brass Dial — dimensional brass/violet instrument with animated energy ring and turn response.

## Preserved
- Existing hit zones and optional-world interaction IDs.
- Shooting-star window secret.
- Pressure-plate secret.
- Quip tap easter egg.
- Shadow Chase mission state machine.
- Optics, dragging, Question Compass, Question Gate, Supabase schema.

## Build ID
`P1.2B-HF1`
