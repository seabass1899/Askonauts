# Install P2.1-HF2

Expected base: ASKONAUTS P2.1-HF1.

1. Back up the current project.
2. Extract this ZIP over the project root.
3. Replace files when prompted.
4. Run:

```bat
npm run build
npm run dev
```

The hotfix replaces only:

`src/game/scenes/ClubhouseScene.ts`

No saved player progress should be removed.
