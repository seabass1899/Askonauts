# Install P1.2B-HF5

Extract this ZIP into the ASKONAUTS project root and replace files in the destination.

Then run:

```bat
npm run build
```

If clean:

```bat
npm run dev
```

Test the Brass Dial repeatedly. It should rotate/pulse but always return to the same compact production size.
