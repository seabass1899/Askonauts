# Install P1.2B-HF3

Install over the working P1.2B-HF2 project.

1. Extract this ZIP into the ASKONAUTS project root.
2. Choose **Replace files in destination**.
3. Do not delete `.vercel`, `.env.local`, or `node_modules`.
4. Run:

```bat
npm run build
```

5. If the build succeeds, run:

```bat
npm run dev
```

Verify the title reads `SHADOW CHASE • P1.2B-HF3`.

## Smoke test
- Tap the Telescope: confirm physical scan motion, blue scan beam, reticle/glint, constellation reveal, Quip reaction, and sound.
- Tap the Prism: confirm bounce/tilt, larger rainbow spill, spectral particles, Quip reaction, and sound.
- Tap the Question Jar: confirm shake, glow, question marks escaping the jar, question card, Quip reaction, and sound.
- Tap the Brass Dial several times: confirm only the dial face rotates while the pedestal stays planted, and the lab produces expanding energy waves/color pulses.
- Finish Shadow Chase normally and verify Question Compass, Free Experiment, Question Gate, and telemetry still work.
