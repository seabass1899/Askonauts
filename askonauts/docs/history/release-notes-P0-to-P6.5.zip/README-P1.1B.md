# ASKONAUTS P1.1B — Delight & Engagement Pass

P1.1B builds on the working P1.1A-HF3 Light Lab without changing the optics math, mission thresholds, drag bounds, Question Compass flow, Question Gate flow, or Supabase schema.

## What changed

- Added a child-facing challenge ribbon for the core Shadow Chase beats.
- Added a visible Curiosity Spark counter.
- Added animated stage-completion rewards and Spark flights toward the lab Compass area.
- Added stage-specific Quip reactions so discoveries feel like shared moments rather than silent state changes.
- Added a continuous subtle Quip ambient beat after the first interaction.
- Added living-lab motion: star twinkles and a moving gauge needle.
- Added one optional Lab Secret: tapping the star window launches a shooting star and Quip reaction.
- Added stronger synthesized discovery/secret sounds.
- Added `delight_event` telemetry and a derived `delight_event_count` in the admin results/CSV.
- Build id is `P1.1B`.

## What did not change

- Quip, lamp, and blocker drag mechanics
- shadow projection math
- mission discovery requirements
- free experiment target (5 meaningful interactions)
- Evidence Lock behavior
- Question Gate behavior
- Supabase table schema

## Local smoke test

1. Run `npm run build`.
2. Run `npm run dev`.
3. Start a fresh test and verify the top-center challenge ribbon is visible.
4. Complete each core challenge and verify a short `CLUE FOUND` reward appears with Curiosity Sparks.
5. Verify Quip reacts after discoveries.
6. Wait a few seconds during normal play and confirm Quip has subtle ambient movement.
7. Tap the starry window once and confirm the optional shooting-star Lab Secret fires only once.
8. Finish Evidence Lock, Free Experiment, Question Gate, and mission completion.
9. Press `P` and confirm the existing mission telemetry is still intact.
10. On the admin dashboard, P1.1B sessions should expose a Delight count and CSV field.

## P1.1B design intent

The goal is not to lengthen the mission with filler. The goal is to increase *engagement density*: every meaningful experiment should produce visible, audible, or character feedback, while the room itself feels alive even between actions.
