# ASKONAUTS P2.2-HF1 — Question Compass Visibility Fix

Small visual hotfix for P2.2.

## Cause
The Question Compass was being created at `x=640, y=332` at depth 12. The Clubhouse characters render at depths 14–16, so the cast covered the Compass almost completely even though its interaction/tree code was present.

## Fix
- Moves the Compass upward into the open center-wall space (`y=226`).
- Keeps the Question Tree logic unchanged.
- Keeps character composition unchanged.
- Moves the Compass labels with the Compass.
- Updates visible build marker to `P2.2-HF1`.

Apply over P2.2, replace files, then run:

```bat
npm run build
npm run dev
```
