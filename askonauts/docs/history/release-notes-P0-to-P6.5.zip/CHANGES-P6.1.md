# P6.1 Changes

- Full Clubhouse UI/layout overhaul.
- Unified top command bar and quick navigation.
- Dedicated discovery, mission, question, progression, and character zones.
- Trophy dock no longer shares the character floor space.
- Reworked Star Window and Spark Vessel presentation.
- Rebalanced full-body Veya / Quip / Teyo stage.
- Refreshed modal color/border hierarchy for Journal, Tree, and Mission Board.
- Preserved P5.9 dynamic mission engine and progression systems.
