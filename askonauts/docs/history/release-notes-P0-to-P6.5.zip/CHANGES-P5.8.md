# Changes — P5.8

- Added replay variants to Light Rescue.
- Added randomized starting states and optional two-move bonus mode to Spoon Sprint.
- Added Prediction, Riddle, and Science Clue prompt variants to Mirror Mission.
- Updated Mission Board descriptions to communicate replay variation.
- Updated visible build markers to P5.8.
- No new Sparks, lives, penalties, or grind mechanics.
