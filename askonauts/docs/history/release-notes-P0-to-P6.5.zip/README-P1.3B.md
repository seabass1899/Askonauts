# ASKONAUTS P1.3B — Voice, Pacing & Child Guidance

P1.3B is a contained child-guidance pass on top of the validated P1.3A Teaching Fidelity & Interaction Repair build.

## Goals

A young player should be able to understand and progress through Shadow Chase by watching, listening and experimenting instead of relying on small text.

## What changed

- Added `VoiceDirector`, a presentation-only voice layer that does not change `MissionDirector`.
- Browser speech synthesis provides an immediate development/fallback Quip voice.
- Added stable voice line IDs so recorded ElevenLabs assets can replace TTS later without changing mission logic.
- Added an on-screen voice mute/unmute control.
- Character nudges now have spoken equivalents.
- Core stage discoveries now trigger short spoken Quip reactions.
- Question Gate and evidence beats have spoken guidance.
- Evidence Compass reveal is delayed 2.4 seconds after the blocker discovery so the rock shadow remains visible long enough to observe.
- Evidence locking is now 1.6 seconds and can be finished immediately with a second tap.
- Increased child-facing challenge/HUD typography.
- Increased Question Compass instructional typography.
- Build label/version updated to P1.3B.

## What did not change

- Shadow projection math or thresholds
- Mission stages or discovery requirements
- Drag bounds
- Blocker logic
- Curiosity Spark scoring
- Question Gate mission progression
- Supabase schema

## Voice strategy

P1.3B intentionally uses browser speech synthesis as a zero-asset development voice. This verifies timing, interruption behavior and child comprehension before committing to final recordings.

The next audio-quality pass can replace the TTS output with canonical ElevenLabs Quip recordings keyed by the same line IDs documented in `VOICE-LINES-P1.3B.md`.
