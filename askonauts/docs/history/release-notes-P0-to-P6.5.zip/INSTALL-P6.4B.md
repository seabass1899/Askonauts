# Install — P6.4B

## Overlay method (recommended if you already have P6.4A-HF8)
1. Back up the current ASKONAUTS project.
2. Extract the P6.4B overlay into the project root and allow it to overwrite matching files.
3. From the project root run:

```bash
npm install
npm run dev
```

4. Hard refresh the browser (`Ctrl+F5`).
5. Confirm Spoon Lab shows `LIVE • P6.4B`.

## Full-source method
1. Extract the full-source ZIP into a new folder.
2. Run:

```bash
npm install
npm run dev
```

3. Open the local Vite URL and test Spoon Lab.

## Validation note
TypeScript validation passed for P6.4B. A production Vite bundle could not be produced in the Linux validation container because the supplied project dependency set was installed on Windows and therefore did not include Rollup's Linux native optional package. This does not affect a normal `npm install` on the target machine.
