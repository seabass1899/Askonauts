# ASKONAUTS P1.1A-HF1 — Visual Integration Hotfix

This hotfix does not change mission mechanics.

Changes:
- Makes the latest approved Light Lab concept visibly drive the live upper-room environment.
- Removes the duplicate procedural window/shelves/chalkboard/Compass-dock layer from that area.
- Repairs Quip's clipped left-ear silhouette in the live runtime without changing touch/drag geometry.
- Bumps telemetry build id to `P1.1A-HF1` and allows that build in the telemetry API.

Install by extracting over the current project root and choosing Replace files in destination.
Then run `npm run build` and `npm run dev`.
