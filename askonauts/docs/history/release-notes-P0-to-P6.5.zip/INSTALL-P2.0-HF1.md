# Install P2.0-HF1

Expected base: ASKONAUTS P2.0.

1. Back up the working project.
2. Extract this ZIP into the project root.
3. Choose **Replace files in destination**.
4. Run `npm run build`.
5. Run `npm run dev`.

Validate the Clubhouse first: Veya, Teyo and Quip should all appear at balanced scale, with Veya and Teyo matching the warmer, melanin-rich episode direction.
