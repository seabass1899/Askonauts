# Install P1.2A-HF1

Extract the ZIP directly into the existing ASKONAUTS project root and choose **Replace files in destination**.

Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
```

If that passes:

```bat
npm run dev
```

Verify the title reads `SHADOW CHASE • P1.2A-HF1`.

Check especially:

1. the prompt card no longer dominates the room after a few seconds;
2. the floor feels integrated rather than like a development grid;
3. the observation screen is less visually overpowering;
4. Quip and blocker shadows remain completely inside the projection surface with no grey rectangular spill;
5. the full mission still reaches `complete / 20 Sparks`.
