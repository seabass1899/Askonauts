# ASKONAUTS P5.5 — Mission Progression & Mastery Ranks

Adds persistent mission mastery without XP grinding.

Ranks:
- Explorer
- Investigator
- Discoverer
- Master Askonaut

Mission mastery:
- Shadow Quest
- Light Rescue
- Spoon Sprint
- Mirror Mission

The Clubhouse header and Mission Board show mastery progress. Rank-up celebrations appear in the Clubhouse after a new rank is earned. Mission replay does not create extra rank progress.
