# P1.2A-HF2 changes

- full-screen ENVELOP composition
- safe-crop title / Parent positions
- compact retracting Free Experiment HUD
- dynamic Quip/blocker depth ordering
- rebuilt Quip core/soft shadow textures
- refined blocker shadow opacity
- reduced Question Gate modal dominance
- telemetry build ID `P1.2A-HF2`
