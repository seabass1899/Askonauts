# ASKONAUTS P5.6-HF2

Focused Clubhouse layout hotfix for the reward zone.

The Discovery Trophies and Master Askonaut status now share one protected wall-mounted area above the character stage so rewards remain readable and tappable.
