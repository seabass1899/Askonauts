# ASKONAUTS P6.1-HF1 — Strict TypeScript Build Fix

Apply this overlay over P6.1.

Fixes only strict TypeScript build blockers in `ClubhouseScene.ts`:
- removed unused Spark Vessel label background variable binding
- removed unused `shadowCompleted` parameter from `createQuestionCompass()` and its call
- removed unused Question Gate label rectangle variable binding

No gameplay, layout, persistence, progression, mission, or visual behavior was intentionally changed.
