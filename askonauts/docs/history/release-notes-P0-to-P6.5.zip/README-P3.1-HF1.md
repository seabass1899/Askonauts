# ASKONAUTS P3.1-HF1 — Completed World Revisit Navigation

Fixes completed-world navigation in the Question Tree.

## Changes
- Completed Shadow Chase and Reflection Hunt nodes now visibly say `COMPLETED • TAP TO REVISIT`.
- A single tap on a completed world node launches that world immediately.
- Reflection Hunt remains permanently replayable after completion even after the Question Gate advances to the next mystery.
- No Reflection Lab mechanics, discoveries, challenge progress, Sparks, identity, or persistence logic are changed.

## Install
Extract over the current P3.1 project and replace files. Then run:

```bat
npm run build
npm run dev
```

The Clubhouse header should show `P3.1-HF1`.
