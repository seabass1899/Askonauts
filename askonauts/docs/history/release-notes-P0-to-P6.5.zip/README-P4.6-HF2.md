# ASKONAUTS P4.6-HF2

Focused visual hotfix for Funhouse Mirrors. The explanation text and progress status now live inside a dedicated right-side panel so they stay readable for every mirror shape.
