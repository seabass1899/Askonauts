# ASKONAUTS P1.0 Stage B — Parent Panel Layout Hotfix

This hotfix changes only `src/game/systems/PlaytestPanel.ts`.

Changes:
- increases parent/playtest card height from 610 to 680 virtual pixels;
- moves the button row from y=628 to y=668;
- reduces button height from 56 to 48 pixels;
- keeps all mission, telemetry, and gameplay logic unchanged.

Expected result: Mission stage, Mission discoveries, and Curiosity Sparks remain fully visible above the button row.
