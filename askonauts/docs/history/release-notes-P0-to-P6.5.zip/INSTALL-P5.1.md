# Install P5.1

Apply this overlay over the current P5.0 project (including the P4.6 hotfixes already installed).

Then run:

```bat
npm run build
npm run dev
```

In the Clubhouse, tap **MISSION BOARD** and launch LIGHT RESCUE, SPOON SPRINT, or MIRROR MISSION directly.
