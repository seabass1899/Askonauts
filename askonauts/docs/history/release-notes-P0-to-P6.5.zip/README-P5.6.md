# ASKONAUTS P5.6 — Clubhouse Evolves With Progress

P5.6 makes the Clubhouse visibly respond to the child's accomplishments without adding XP grind or a new save schema.

## Added
- Discovery Trophy shelf with one derived trophy for each completed world.
- Trophy interactions that recap what the child discovered.
- Spark Vessel evolution states: WARMING, AWAKE, GLOWING, RADIANT.
- Extra Spark Vessel aura/motes at higher Spark totals.
- Rank stars on the Clubhouse rug based on Askonaut mastery rank.
- MASTER ASKONAUT CLUBHOUSE banner when all four current mastery missions are complete.

## Persistence
All P5.6 environmental evolution is derived from existing world progress, Curiosity Sparks, and mastery progress. No new persistence schema is introduced.

## Visual-debt note
Quip's Clubhouse asset still needs a dedicated canonical-art revisit. P5.6 intentionally does not modify Quip.
