# Install

Overlay this package onto P6.2, then run:

```bat
npm run build
npm run dev
```

Hard refresh with Ctrl+F5 if the browser cached the prior bundle.
