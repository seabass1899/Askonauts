# ASKONAUTS P5.7 — Audio Personality

Adds character-specific browser-TTS personalities and tighter spoken reactions across the Clubhouse, Reflection Hunt, Spoon Lab, and Funhouse Mirrors.

## Character audio roles
- Veya: curious, observant, prediction/science framing
- Teyo: practical, calm, problem-solving guidance
- Quip: quicker, playful comic reactions

The VoiceDirector remains backward compatible and still respects the existing mute control, duplicate-line protection, priorities, and exclusive narration.

Known visual debt intentionally deferred: canonical Quip Clubhouse art and final Clubhouse reward/trophy layout.
