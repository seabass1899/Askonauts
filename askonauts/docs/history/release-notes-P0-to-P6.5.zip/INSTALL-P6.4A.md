# Install
1. Extract this ZIP over the current ASKONAUTS project, preserving folders.
2. Run `npm run build`.
3. Run `npm run dev`.
4. Hard refresh with `Ctrl + F5` if the old scene is cached.
