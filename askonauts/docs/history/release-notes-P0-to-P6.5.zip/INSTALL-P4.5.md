# Install P4.5

Apply this overlay over the working P4.1 project and replace matching files.

Then run:

```bat
npm run build
npm run dev
```

No save reset is required.
