# Install P5.4

Apply this overlay on top of the current P5.3 build.

Then run:

```bat
npm run build
npm run dev
```

Visible build markers in the updated scenes should read P5.4.
