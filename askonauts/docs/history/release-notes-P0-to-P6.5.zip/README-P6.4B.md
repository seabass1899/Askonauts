# ASKONAUTS P6.4B

**Global Navigation & Systems Pass**

P6.4B moves ASKONAUTS away from one-off scene navigation toward a shared application shell. The first production integration is Spoon Lab, built directly on the accepted P6.4A-HF8 baseline.

## What to test first

1. Start Spoon Lab and confirm the marker reads `LIVE • P6.4B`.
2. Click **JOURNAL**. It should open the Discovery Journal as an overlay without leaving Spoon Lab.
3. Close Journal and click **TREE**. The Question Tree should open as an overlay.
4. Click **SETTINGS**. Change Master Audio / Voice / SFX, close the modal, reopen it, and confirm the choices persist.
5. Click **AUDIO** in the painted header. A small `AUDIO MUTED` / `AUDIO ON` acknowledgement should appear and narration should follow the master state.
6. Click **CLUBHOUSE** and verify normal navigation.
7. Return to Spoon Lab and inspect **CURRENT DISCOVERY**. Live copy should no longer sit directly on top of the baked body copy.
8. Verify the left activities, experiment tools, bottom distance controls, spoon flipping, discoveries, and Spoon Sprint still work as they did in HF8.

## Architecture introduced

- `src/game/ui/GlobalGameUI.ts`
- `src/game/ui/DiscoveryJournalOverlay.ts`
- `src/game/ui/QuestionTreeOverlay.ts`
- `src/game/ui/SettingsOverlay.ts`
- `src/game/settings/GameSettingsStore.ts`
- `src/game/systems/AudioManager.ts`

The old scene-specific systems are intentionally left in place outside Spoon Lab until P6.4C. This keeps the migration controlled and prevents a navigation refactor from destabilizing every discovery world at once.
