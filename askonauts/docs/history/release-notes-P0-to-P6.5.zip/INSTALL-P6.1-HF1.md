# Install P6.1-HF1

1. Extract this ZIP over your current P6.1 project root.
2. Allow it to overwrite `src/game/scenes/ClubhouseScene.ts`.
3. Run:

```bat
npm run build
npm run dev
```
