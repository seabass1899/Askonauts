# ASKONAUTS P2.1 — ASKONAUT Player Identity

P2.1 adds the first persistent player identity layer to ASKONAUTS Question World.

## What changed

- First-run ASKONAUT identity setup in the Clubhouse.
- Child chooses an ASKONAUT name (up to 18 characters).
- Child chooses one of three emblems: Star, Builder Gear, or Comet.
- Child chooses one of four accent colors: Violet, Gold, Cyan, or Rose.
- Identity persists locally with the existing player progress.
- Existing P1.4/P2.0 progress is migrated without wiping Sparks, discoveries, secrets, unlocks, or completion state.
- Clubhouse header shows the player's emblem/name and can be tapped to edit identity later.
- Veya and Teyo address the child by ASKONAUT name in Clubhouse interactions.
- Shadow Chase carries the same ASKONAUT identity into the Light Lab header.
- Telemetry build marker is `P2.1`.

## Product intent

The player is no longer only operating ASKONAUTS. They now have a persistent identity inside the ecosystem as the fourth ASKONAUT.

P2.1 deliberately does not add accounts, email, cloud sync, subscriptions, or a full custom character creator. Those belong after the local identity loop is validated with children.

## Validation completed

- Changed TypeScript files transpile/syntax check: PASS
- v1 -> v2 progress migration preserves world progress: implemented
- identity can be edited after first setup: implemented
- mobile/desktop name input uses a temporary HTML text field so touch keyboards can appear
