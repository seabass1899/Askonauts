# P5.2-HF1 — Quip Ear Framing Fix

- Corrects the clipped-ear appearance of Quip in the Clubhouse.
- Adds small tapered ear-tip continuations behind the existing canonical Quip sprite.
- Keeps Veya and Teyo unchanged.
- Keeps Mission Board, character reactions, Sparks, discoveries, saves, and progression unchanged.
- Updates the Clubhouse build marker to P5.2-HF1.
