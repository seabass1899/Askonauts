# P2.2 changes

- Added `src/game/questions/QuestionTree.ts` as a pure progress-to-question-state adapter.
- Question Compass now opens a full Question Tree overlay.
- Added completed, available, discovered, and mystery question states.
- Added initial Shadow → Reflection / Shadow Size branching structure.
- Added direct Shadow Chase revisit/launch behavior from the tree.
- Added progress-derived Shadow Size resolution from existing discoveries.
- Added Reflection Hunt discovery state after Shadow Chase completion.
- Added future mystery branches for two-shadow and spoon-reflection questions.
- Updated build marker to `P2.2`.
- Updated package version to `2.2.0-question-compass-tree`.
- No identity, age-band/profile, mission, Spark, or persistence schema changes.
