# P1 Stage D changes

- Added canonical-inspired brass/gold + glowing-blue Question Compass visual.
- Added interactive Evidence Lock overlay.
- Added LIGHT / BLOCK / SHADOW evidence reflection cards.
- Added Compass wake and evidence-lock synthesized SFX.
- Added transition to `free_experiment` after evidence confirmation.
- Added Free Experiment banner.
- Added Compass/evidence telemetry and admin dashboard support.
- Added `P1.0D` to telemetry backend allow-list.
- Compacted parent diagnostic panel so Stage D telemetry remains visible above controls.
