# P1.4 changes

- Added Question World registry.
- Added persistent player/world progress.
- Added Clubhouse foundation scene.
- Changed application startup to Clubhouse -> world launch.
- Persisted Shadow Chase Sparks, discoveries, secrets, and completion.
- Reflection Hunt question unlocks after Shadow Chase completion.
- Added return-to-Clubhouse lifecycle from Question Gate.
- Removed browser reload as the primary replay/navigation mechanism.
