# P1.3A Changes

- Preserve P1.2D mission flow and Question Gate cinematic.
- Render true projected Quip shadow scale rather than fitting every shadow inside the observation screen.
- Crop oversized Quip and rock shadows at the observation-screen boundary without Phaser 4 GeometryMask.
- Start Quip farther from the lamp for a medium opening shadow.
- Wire MissionDirector `activeHint` cues into visible scene feedback.
- Ensure blocker drag zone always wins input overlap with Quip.
- Clip light beam geometry at the floor instead of using unsupported WebGL masks.
- Increase Question Gate layout separation and delay Gate awakening until Quip dialogue clears.
- Replace telemetry build-name allowlist with validated build-ID pattern.
- Build ID: `P1.3A`.
