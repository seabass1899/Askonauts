# P1.2B changes

- Added InteractiveWorldSystem with seven optional exploration behaviors.
- Added five tracked Light Lab secrets plus Quip's repeat-tap easter egg.
- Added telescope constellation reveal, prism rainbow, Question Jar, brass dial pulse, shooting-star window, and pressure-plate secret drawer.
- Optional world interactions do not advance MissionDirector stages.
- Added synthesized world-interaction SFX.
- Added P1.2B world-interaction telemetry and admin/CSV reporting.
- Replaced the two opaque lower-corner foreground blocks with integrated brass consoles.
- Updated build identifier to P1.2B.
