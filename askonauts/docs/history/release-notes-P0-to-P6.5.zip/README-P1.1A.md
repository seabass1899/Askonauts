# ASKONAUTS — Shadow Chase P1.1A

P1.1A is the first Presentation & Delight pass. It keeps the complete P1.0F
mission architecture and replaces the prototype room presentation with the
Light Lab visual system.

## Visual changes
- layered warm wood / brass / violet Light Lab environment
- star-window and distant world silhouette
- shelves, books, prisms, chalkboard and Question Compass docking station
- brass-framed observation screen with subtle grid
- glowing Quip experiment pad and floor track
- redesigned brass/indigo discovery lamp
- redesigned blocker rock on a brass trolley
- warm/cool room lighting states tied to the lamp switch
- animated ambient dust motes
- foreground depth props

## Preserved systems
No mission mechanics were intentionally changed:
- Quip, lamp and blocker drag geometry
- shadow projection math
- Light ON/OFF behavior
- MissionDirector progression
- Question Compass / Free Experiment / Question Gate
- telemetry and parent/admin workflows

## Build identifier
`P1.1A`
