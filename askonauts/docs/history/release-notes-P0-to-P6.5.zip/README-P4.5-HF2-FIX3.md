# ASKONAUTS P4.5-HF2-FIX3 — Clubhouse Character Asset Restore

Restores the exact Clubhouse character textures referenced by the current ClubhouseScene.

Apply over P4.5-HF2-FIX2.
