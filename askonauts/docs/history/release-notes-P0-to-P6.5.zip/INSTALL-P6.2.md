# Install P6.2

Apply this overlay over ASKONAUTS P6.1-HF2.

1. Extract this ZIP into the project root.
2. Allow `src/game/scenes/ClubhouseScene.ts` to overwrite the existing file.
3. Run:

```bat
npm run build
npm run dev
```

4. Hard refresh the browser if needed:

```text
Ctrl + F5
```

No save-data reset is required.
