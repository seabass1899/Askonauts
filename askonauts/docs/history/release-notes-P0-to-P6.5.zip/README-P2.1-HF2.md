# ASKONAUTS P2.1-HF2 — ASKONAUT Welcome Experience

This hotfix polishes the P2.1 player-identity onboarding without changing persistence, world progression, or Shadow Chase gameplay.

## What changed

- Reframed onboarding from a settings form into an ASKONAUT initiation moment.
- New first-run title: `WELCOME, NEW ASKONAUT!`.
- Editing identity now uses `YOUR ASKONAUT BADGE`.
- Added a live badge preview combining name, emblem, and accent color.
- Reworded setup prompts into child-facing language:
  - What should we call you?
  - Choose your ASKONAUT symbol
  - Pick your badge color
- Added contextual Veya, Teyo, and Quip reactions as choices change.
- Replaced `I'M READY!` with `JOIN THE TEAM`.
- Added a short completion ceremony:
  - badge reveal
  - Spark burst
  - personalized `WELCOME TO THE TEAM, <NAME>!`
  - Quip welcome line
- Identity editing uses `SAVE MY BADGE`.
- Clubhouse build marker is `P2.1-HF2`.

## What did not change

- PlayerProgressStore schema or migration
- saved Sparks/discoveries/secrets
- WorldRegistry
- Shadow Chase mission logic
- Question Gate logic
- telemetry behavior

## Expected flow

1. Open the Clubhouse with an incomplete ASKONAUT identity.
2. The welcome panel appears.
3. Choose/edit the name.
4. Select Star, Builder, or Comet.
5. Select a badge color.
6. Confirm with `JOIN THE TEAM`.
7. A short badge/Spark celebration plays.
8. Clubhouse restarts with the saved identity visible.
