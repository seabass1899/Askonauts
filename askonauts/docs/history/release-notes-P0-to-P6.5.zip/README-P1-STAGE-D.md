# ASKONAUTS P1.0 — Stage D: Question Compass / Evidence Lock

Stage D turns the `evidence_lock` mission state into a child-facing ASKONAUTS moment.
It is deliberately **not a quiz**. The child already discovered the evidence through play;
the Question Compass reflects those discoveries and lets the child lock them in.

## New behavior

When Stage C advances the mission to `evidence_lock`:

1. The world dims and the Question Compass appears.
2. Three discovered evidence cards are shown: **LIGHT**, **BLOCK**, **SHADOW**.
3. The Compass pulses as the only required interaction.
4. The child taps the Compass.
5. The evidence animates into the Compass and locks.
6. The mission receives `evidence_confirmed`.
7. The mission advances to `free_experiment`.
8. A brief **FREE EXPERIMENT — What else can you make happen?** banner appears and the sandbox returns.

## Expected diagnostic state after locking evidence

- Mission stage: `free_experiment`
- Mission discoveries: `12`
- Curiosity Sparks: `15`
- Compass taps: `1`
- Evidence locked: `YES`

## Telemetry

P1.0D adds:

- `firstCompassTapMs`
- `compassTapCount`
- `evidenceLocked`
- `compass_tap` event
- `evidence_lock` event

These fields are stored inside the existing `raw_summary`; no Supabase schema change is required.
The results API/admin dashboard derive the new Compass metrics from `raw_summary`.

## Build identifier

`P1.0D`
