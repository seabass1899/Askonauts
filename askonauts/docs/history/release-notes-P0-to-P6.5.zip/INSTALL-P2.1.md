# Installing ASKONAUTS P2.1

Expected base: **P2.0-HF1-V2**.

1. Back up the current ASKONAUTS project.
2. Extract this ZIP directly over the project root.
3. Choose **Replace files in destination**.
4. Do not delete `.env.local`, `.vercel`, or `node_modules` from the local project.
5. Run:

```bat
npm run build
npm run dev
```

## First-run test

When the Clubhouse loads after upgrading, the ASKONAUT identity card should appear once.

1. Set a name.
2. Choose an emblem.
3. Choose an accent color.
4. Select **I'M READY!**.
5. Verify the Clubhouse restarts with the selected name/emblem in the header.
6. Tap Veya/Teyo and verify they use the ASKONAUT name.
7. Enter Shadow Chase and verify the same identity appears in the Light Lab header.
8. Return to the Clubhouse and refresh the browser. Identity and existing mission progress should persist.

The identity chip in the Clubhouse header can be tapped later to edit the player's identity.
