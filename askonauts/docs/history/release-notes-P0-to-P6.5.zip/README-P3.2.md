# ASKONAUTS P3.2 — Reflection Feedback & Completion Polish

P3.2 closes the Reflection Hunt functional cycle without adding new science mechanics.

## Included
- Strong challenge-completion feedback with target flash, banner, and Curiosity Spark confirmation.
- Cleaner Challenge Lab/header spacing.
- Progress/status panel moved away from the primary controls.
- First-time Reflection Hunt completion now uses a dedicated completion overlay rather than placing a Question Gate over the reflection target.
- Completion overlay reveals the next question: **Why does a spoon flip your reflection?**
- Completion overlay offers **TRY CHALLENGES** or **RETURN TO CLUBHOUSE**.
- Revisiting an already-completed Reflection Hunt leaves the target wall clear for experimentation/challenges.
- Clubhouse visible build marker updated to P3.2.

## Base
Apply over ASKONAUTS P3.1-HF2.
