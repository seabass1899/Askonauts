# Install P1.2C-HF1

Extract this ZIP directly over the current ASKONAUTS project root and choose **Replace files in destination**.

Then run:

```bat
npm run build
```

If clean:

```bat
npm run dev
```
