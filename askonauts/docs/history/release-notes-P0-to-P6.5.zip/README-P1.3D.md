# ASKONAUTS P1.3D — Experimental Freedom & Replay

P1.3D builds on the working **P1.3C-HF2** Shadow Chase mission. It turns the post-evidence Free Experiment phase from a five-interaction counter into a discovery-driven light sandbox.

## Core change

The child now discovers distinct light behaviors rather than simply moving objects five times.

Three Light Lab Secrets are available:

1. **OUTSIDE LIGHT** — move Quip out of the beam while the lamp remains on.
2. **ROCK BLOCK** — place the rock between the lamp and Quip so the rock blocks Quip's light.
3. **GIANT SHADOW** — create a shadow large enough to exceed the normal observation-screen scale.

Finding **any 2 of 3** opens the Question Gate. The third remains optional and can still be discovered through Explore More.

## Curiosity Sparks

Each unique sandbox discovery earns one Spark. Repeating the same behavior does not award another Spark.

The Free Experiment stage itself awards zero additional stage Sparks, so the core two-discovery path preserves the previous two-Spark total while tying those Sparks to meaningful discoveries.

## Architecture

`SandboxDiscoverySystem` observes semantic light/shadow state and emits only:

- `left_beam`
- `blocker_occlusion`
- `giant_shadow`

`MissionDirector` receives those as `sandbox_discovery` signals. It still has no dependency on Phaser geometry, beam polygons, sprites, or coordinates.

## Replay / Explore More

The Question Gate completion panel now reports the number of Light Lab Secrets found. If secrets remain, PLAY AGAIN becomes **FIND LAST SECRET** / **FIND MORE SECRETS**.

Choosing Explore More before or after Gate completion allows remaining sandbox secrets to be discovered without corrupting mission completion state.

## Build marker

Child-facing build marker and telemetry build ID: `P1.3D`.
