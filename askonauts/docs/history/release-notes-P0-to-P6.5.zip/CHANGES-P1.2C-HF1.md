# P1.2C-HF1 — Production Rock Integration

- Replaced the procedural gray polygon blocker rock with the approved production boulder art.
- Preserved the blocker trolley, drag zone, mission discovery logic, pressure-plate secret, and movement telemetry.
- Added a grounded contact shadow beneath the boulder on the trolley.
- Updated grab/release animation so the production rock lifts slightly while dragging and settles naturally afterward.
- Replaced the blocker’s generic ellipse projection with the real boulder silhouette on the Observation Screen.
- Updated build/telemetry identifier to `P1.2C-HF1`.
- No Supabase schema change is required.
