# ASKONAUTS P6.4C — Shared Shell Propagation

P6.4C carries the P6.4B shared application shell out of Spoon Lab and across the rest of the game without changing core experiment logic.

## Implemented

- Propagated `GlobalGameUI` to:
  - Shadow Chase
  - Reflection Hunt
  - Spoon Lab
  - Funhouse Mirrors
  - Clubhouse
- Propagated `AudioManager` to all five primary scenes.
- Removed direct per-scene `VoiceDirector` construction; scenes now use the shared audio facade's voice layer.
- Shadow Chase SFX now run through `AudioManager.sfx`, so the global master mute and SFX setting affect Shadow Chase as well.
- Removed Shadow Chase's separate persistent Clubhouse button and replaced it with the shared shell.
- Preserved the Parent playtest control in Shadow Chase and moved it away from the shared utility rail.
- Reflection Hunt keeps its LIGHT RESCUE mission button while gaining Journal / Tree / Settings / Audio / Clubhouse from the shared shell.
- Funhouse Mirrors now exposes the same global utilities.
- Clubhouse now uses the same Journal / Tree / Settings / Audio implementation as the worlds; Home is omitted because Clubhouse is already home.
- Spoon Lab remains the painted-header implementation and continues to use invisible semantic hotspots over the illustrated controls.
- Audio icons stay synchronized with persisted master mute state in rendered and painted headers.
- Spoon Lab runtime marker advanced to `LIVE • P6.4C`.

## Architectural rule retained

Environment art owns scenery and decorative chrome. Phaser owns interactive controls, changing text, state, overlays, settings, audio state, and navigation semantics.

## Validation

`npx tsc --noEmit` passes.

Source-level regression checks confirm:

- all five primary scenes instantiate `GlobalGameUI`;
- all five primary scenes instantiate `AudioManager`;
- no scene directly constructs `VoiceDirector`;
- the legacy Shadow Chase persistent Clubhouse control has been removed.
