# P1.2A changes

- production Quip motion rig and integrated speech bubble
- animated discovery lamp lens/rotor/status presentation
- rolling/lifting blocker trolley presentation
- production Light Lab depth, floor, ambient and environmental animation pass
- Question Compass hero-instrument visual/animation pass
- enhanced production Light Lab scenic asset
- build/telemetry identifier updated to P1.2A
