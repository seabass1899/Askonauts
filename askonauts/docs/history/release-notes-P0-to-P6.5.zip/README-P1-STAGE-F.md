# ASKONAUTS — Shadow Chase P1.0F
## Stage F: Question Gate

P1.0F completes the first Shadow Chase mission loop.

After the child finishes the five Free Experiment interactions, the Question Gate awakens. The child can:

- **ENTER GATE** — complete Shadow Chase and reveal the Reflection Hunt teaser.
- **EXPLORE MORE** — return to the sandbox while a persistent Question Gate marker remains available.

Entering the Gate advances MissionDirector from `question_gate` to `complete`, producing the intended final state:

- Mission stage: `complete`
- Mission discoveries: `14`
- Curiosity Sparks: `20`

Stage F also adds Question Gate telemetry, parent-panel diagnostics, and admin-dashboard aggregation. No Supabase schema migration is required because the additional P1 fields are stored in `raw_summary` and derived by `/api/results`.

## Local validation

1. Run `npm run build`.
2. Run `npm run dev`.
3. Play through to `question_gate` (13 discoveries / 17 Sparks / 5 of 5 Free Experiment interactions).
4. Verify the Gate awakens.
5. Choose **EXPLORE MORE** once and confirm normal interaction returns and the small Gate marker remains.
6. Tap the marker to reopen the Gate.
7. Choose **ENTER GATE**.
8. Open the Parent panel and verify approximately:
   - Mission stage: `complete`
   - Mission discoveries: `14`
   - Curiosity Sparks: `20`
   - Question Gate revealed: `YES`
   - Question Gate entered: `YES`
   - Explore-more choices: `1`
   - Mission completed: `YES`
   - Next mystery shown: `YES`
