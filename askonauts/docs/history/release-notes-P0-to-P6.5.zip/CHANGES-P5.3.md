# P5.3 Changes

- Added near-miss and progressive hint feedback to LIGHT RESCUE.
- Added contextual mission hints to SPOON SPRINT after repeated unsuccessful actions.
- Added contextual wrong-answer feedback and confirmation effects to MIRROR MISSION.
- Updated Clubhouse, Reflection Hunt, Spoon Lab, and Funhouse Mirrors build markers to P5.3.
- No save schema, Sparks, discovery IDs, completion IDs, or mission unlock requirements changed.
- No Quip character art changes.
