# Install P1.3A

Base expected: **P1.2D**.

Back up the current working project first, then extract this ZIP into the ASKONAUTS project root and replace files when prompted.

Do **not** include or overwrite secrets/deployment state in shared archives. Keep these local:

- `.env.local`
- `.env*` containing secrets
- `.vercel/`
- `src/playtest/.vercel/`
- `node_modules/`
- `dist/`

Then run:

```bat
npm run build
npm run dev
```

## Smoke test

1. Opening Quip shadow is medium-sized, not already visually capped.
2. Move Quip close to the lamp: shadow becomes dramatically larger and may extend beyond the observation screen.
3. Move Quip far from the lamp: shadow visibly becomes much smaller.
4. Wait through hint thresholds on multiple stages and verify the relevant object/control visibly pulses or Quip gives a nudge.
5. At Block It, overlap Quip's touch area with the rock and verify dragging the rock moves the rock, not Quip.
6. Open browser console under WebGL and verify the previous `setMask is not supported in WebGL` warnings from beam/Quip/blocker shadows are gone.
7. Verify the beam does not spill below the floor line.
8. Complete the mission through Question Gate and verify the Gate CTA/copy no longer collide and Quip's preceding bubble clears before the Gate awakens.
9. Verify telemetry accepts build `P1.3A`.
