# Install — P5.6

Apply this overlay on top of the current P5.5 build.

From the project root:

```bat
npm run build
npm run dev
```

Then hard refresh the browser if needed:

```text
Ctrl + F5
```

## Quick validation
1. Clubhouse header reads P5.6.
2. Discovery Trophy shelf appears beneath the Mission Board area.
3. Completed worlds show colored trophies; incomplete worlds show mystery trophies.
4. Clicking an unlocked trophy produces a readable discovery recap.
5. Spark Vessel state changes according to current Spark total.
6. Askonaut rank is reflected by stars on the rug.
7. Existing Mission Board, Question Compass, Journal, identity, and progression still work.
