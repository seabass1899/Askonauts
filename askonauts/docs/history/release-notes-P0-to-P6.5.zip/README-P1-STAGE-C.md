# ASKONAUTS P1.0 — Stage C: Block It

Stage C adds the first new mission mechanic on top of the validated P1.0B mission plumbing.

## What changed

- A rock/blocker unlocks only when the mission reaches `block_it`.
- The rock uses a large dedicated invisible drag zone for reliable touch input.
- The rock begins outside the visible light beam and must be moved into it.
- A second, independent rock shadow is projected onto the wall.
- `blocker_moved` + `blocker_shadow` are required to complete the Block It stage, preventing accidental auto-completion.
- Completing Block It advances the mission to `evidence_lock`.
- Blocker drags are captured in P1.0C telemetry.
- The admin results endpoint derives blocker and mission metrics from `raw_summary` without requiring a Supabase schema migration.
- Fixed a future mission bug where per-frame blocker observations could have counted as free-experiment interactions.

## Install

Extract this ZIP directly over the current P1.0B project root and choose **Replace files in destination**.
Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

    npm run build
    npm run dev

## Local validation

Play through the existing sequence until the parent panel shows:

    Mission stage: block_it
    Mission discoveries: 9
    Curiosity Sparks: 10

At that point a ROCK should appear near the upper-right side of the experiment room with a pulsing ring.

Drag the rock down into the glowing beam. A second rock-shaped shadow should appear on the projection wall.

Press `P` again. Expected Stage C completion state:

    Mission stage: evidence_lock
    Mission discoveries: 11
    Curiosity Sparks: 13
    Blocker drag starts: >= 1

The mission intentionally stops at `evidence_lock`; Stage D will introduce the Question Compass evidence interaction.

## Validation performed during packaging

- Strict TypeScript check of all `src/*.ts` using a Phaser API type shim: PASS
- MissionDirector deterministic Stage C progression test: PASS
- Verified blocker shadow alone cannot auto-complete Block It before blocker movement: PASS
- Verified repeated per-frame blocker observations do not advance free-experiment progression: PASS
- `api/telemetry.js` syntax check: PASS
- `api/results.js` syntax check: PASS

A full Phaser/Vite production build still needs to be run in the working project where dependencies are installed.
