# P1.2A-HF1 changes

- production composition pass
- compact/retracting challenge HUD
- observation-screen rebalance
- floor and foreground cleanup
- clean transparent shadow assets
- strict projected-shadow containment
- darkened scenic letterbox fill
- telemetry build ID `P1.2A-HF1`
