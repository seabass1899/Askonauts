# P1.2B-HF4 — Jar Reset + Prism Animation

## Fixed
- Question Jar now always returns to its authored display scale after the shake/squash animation.
- Repeated Question Jar taps no longer compound scale or leave the jar enlarged.
- Jar light-spill animation also resets to its baseline state after each interaction.

## Improved
- Prism now performs a stronger multi-beat tilt/pulse animation.
- Prism rainbow spill expands more visibly and returns to baseline cleanly.
- Added animated multicolor light rays and an expanding spectral orbit.
- Existing rainbow reveal and particle burst remain in place.

## Unchanged
- Shadow Chase mission logic
- Prop hit zones and positions
- Lab secrets
- Quip interactions
- Telemetry schema
- Science/optics mechanics
