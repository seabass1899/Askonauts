# Install P1.3C

Expected base: working P1.3B-HF2.

1. Back up the current project.
2. Extract this ZIP over the project root and replace files in destination.
3. Run:

```bat
npm run build
npm run dev
```

This is an overlay, not a standalone project.
