# Install P6.3

1. Extract this ZIP over the existing P6.2-HF1 project root.
2. Allow files to overwrite when prompted.
3. Run:

```bat
npm run build
npm run dev
```

4. Hard refresh the browser with Ctrl+F5.
