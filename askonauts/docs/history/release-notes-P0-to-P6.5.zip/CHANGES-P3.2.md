# Changes — P3.2

## Reflection Lab
- Challenge Lab button repositioned to avoid the audio control.
- Progress/status panel repositioned to reduce overlap with controls.
- Challenge success now produces a visible target flash and centered success banner.
- First-time world completion now presents a dedicated completion overlay.
- Removed the completed-world Question Gate graphic from the reflection target area.
- Revisits keep the target clear and show completion status in the lab message area.

## Clubhouse
- Visible build marker updated to P3.2.

## No changes
- Reflection science rules
- Challenge target definitions
- Player identity
- Age band
- Sparks persistence
- Question Tree progression
- Discovery Journal data model
