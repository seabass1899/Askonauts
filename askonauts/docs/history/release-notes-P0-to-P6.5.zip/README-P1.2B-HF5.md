# ASKONAUTS P1.2B-HF5 — Dial Scale Stability Hotfix

This hotfix fixes the production Brass Dial expanding to its native source-image size after interaction.

## Root cause
The dial uses `setDisplaySize(102, 102)`, so its correct runtime scale is much smaller than 1. The interaction tween incorrectly reset the sprite with `setScale(1)`, which restored the large source artwork at native scale.

## Fix
- Capture the authored dial scale immediately after `setDisplaySize()`.
- Reset to that captured scale before every interaction.
- Tween relative to the captured scale.
- Return to the captured scale when the animation completes.
- Rapid repeated taps cannot compound the scale.

No science logic, mission progression, optional-world interactions, drag mechanics, or Supabase schema changed.
