# ASKONAUTS P6.4-HF1 — Version Sync + Persistent Clubhouse Exit

Apply over P6.4.

Fixes:
- Clubhouse build marker now shows P6.4-HF1.
- Reflection Lab build marker now shows P6.4-HF1.
- The CLUBHOUSE button is promoted above challenge/completion overlays so it remains clickable at all times.
- ESC also returns directly to the Clubhouse while inside Reflection Lab.

No mission logic, discoveries, Sparks, mastery, or save data are changed.
