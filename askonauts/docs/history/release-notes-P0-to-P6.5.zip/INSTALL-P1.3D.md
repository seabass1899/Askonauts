# Install P1.3D

Expected base: **working P1.3C-HF2**.

1. Back up the current project.
2. Extract this ZIP over the project root.
3. Replace files when prompted.
4. Run:

```bat
npm run build
npm run dev
```

## Focused smoke test

Play through Evidence Lock and enter Free Experiment.

Verify:

1. The HUD says LIGHT LAB SECRETS and shows three hidden discoveries.
2. Moving Quip outside the beam with the lamp still ON reveals OUTSIDE LIGHT and awards one Spark.
3. Repeating that same action does not award another Spark.
4. Put Quip back in the beam and place the rock directly between the lamp and Quip. ROCK BLOCK should reveal and award one Spark.
5. After any two unique discoveries, NEW QUESTION DETECTED appears and the Question Gate awakens.
6. Choose Explore More. The sandbox remains usable and the remaining secret can still be found.
7. Create a giant shadow by moving Quip close enough to the lamp. GIANT SHADOW should reveal once.
8. Reopen/enter the Gate. The completion panel should report the correct number of Light Lab Secrets found.
9. If one secret remains, the replay button should read FIND LAST SECRET.
10. Complete the Gate path and verify existing voice arbitration/timing remains clean.

## Validation performed during packaging

- TypeScript syntax transpile: PASS for every changed TypeScript file.
- Strict semantic compile of MissionDirector + mission definitions + SandboxDiscoverySystem: PASS.
- Deterministic mission-state test: PASS.
  - first sandbox discovery: Free Experiment remains active, +1 Spark
  - second unique discovery: advances to Question Gate, +1 Spark
  - third discovery during Question Gate: recorded, +1 Spark
- Full local `npm run build` must still be run in the user's complete project because this package is an overlay and does not contain the entire dependency tree.
