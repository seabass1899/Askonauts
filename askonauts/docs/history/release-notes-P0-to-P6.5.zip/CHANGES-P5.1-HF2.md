# P5.1-HF2 Changes

- Added child-readable timing for Clubhouse character bubbles.
- Extended Reflection Lab discovery and mission feedback timing.
- Added word-count-based display timing to Spoon Lab popups.
- Added word-count-based display timing to Funhouse Mirrors popups.
- Updated visible build markers where applicable to P5.1-HF2.
