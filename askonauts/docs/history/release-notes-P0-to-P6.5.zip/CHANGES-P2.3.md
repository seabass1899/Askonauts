# Changes — P2.3

- Added `DiscoveryJournal.ts` catalog + progress-derived journal builder.
- Discovery Wall now opens a persistent Discovery Journal instead of immediately launching Shadow Chase.
- Added paged Discovery/Secret cards and a detail pane.
- Added kid-friendly science explanations and replay prompts.
- Added `TRY IT AGAIN` replay-focus handoff to Shadow Chase.
- Preserved existing progress schema; no migration/reset required.
- Question Tree completed nodes now display `COMPLETED`.
- Clubhouse build marker updated to P2.3.
