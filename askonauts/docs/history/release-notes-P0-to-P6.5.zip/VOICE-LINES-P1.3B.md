# P1.3B Voice Line Map

These IDs are the stable replacement points for final recorded Quip audio.

| Line ID | Spoken copy |
|---|---|
| `intro.invite` | Try moving me. What happens to my shadow? |
| `hint.mystery` | Try moving me. What does my shadow do? |
| `hint.shadow_follows` | What else can change the shadow? |
| `hint.light_matters` | What if the light changes? |
| `hint.lights_out` | Hmm. What happens if the light is not on? |
| `hint.size_hunt` | Try near, then far. Watch the shadow. |
| `hint.block_it` | What can block the light? |
| `hint.evidence_lock` | The Question Compass is waiting. |
| `hint.free_experiment` | Change one thing. What happens? |
| `hint.question_gate` | The Gate is calling. |
| `stage.mystery` | Wait. It moved with me. |
| `stage.shadow_follows` | Ha! It really follows! |
| `stage.light_matters` | The light moved it too! |
| `stage.lights_out` | No light, no shadow. |
| `stage.size_hunt` | Tiny, huge! That is ridiculous! |
| `stage.block_it` | The rock made a shadow too! |
| `evidence.observe` | Look at the rock's shadow. We made that happen by blocking the light. |
| `compass.lock` | Let's lock the clues together. |
| `evidence.locked` | Evidence locked. Nice work, Askonaut. |
| `free.start` | Try something weird. Change one thing and watch what happens. |
| `free.one` | Ha! It changed! |
| `free.two` | Contextual free-experiment prompt. |
| `gate.detected` | Oh! A new question! |
| `gate.reveal` | Uh oh. I think we found another question. |
| `gate.choice` | I see something shiny in there! |
| `gate.explore` | More experiments? Excellent. |
| `gate.enter` | Yes! Let's go in! |
| `gate.teaser` | A spoon? Why is it doing that? |
