# ASKONAUTS P1.1C — Discovery FX & Rewards

P1.1C builds on the P1.1B Delight & Engagement pass and focuses on making every meaningful discovery feel visible, rewarding, and connected to the Question Compass.

## What changed

- Added an in-world five-segment Compass charge indicator for the five core Shadow Chase discoveries.
- Curiosity Sparks now visibly converge on the Compass area instead of behaving like a detached score effect.
- Added discovery-specific visual feedback:
  - shadow-motion pulse
  - light-beam ripple
  - lights-out star moment
  - shadow-return flash
  - HUGE / TINY shadow feedback
  - second-shadow pulse for the blocker
  - Evidence Lock Compass charge
  - Free Experiment celebration burst
- Added session-local experimentation recognition: CURIOUS!, GREAT ASKING!, and DISCOVERY STREAK! for closely spaced meaningful discoveries.
- Added discovery-specific synthesized audio cues.
- Added `discovery_fx:<discovery>` entries through the existing delight telemetry stream.
- Build id is `P1.1C`.

## What did not change

- optics / shadow projection math
- Quip, lamp, and blocker drag bounds
- mission discovery requirements
- Curiosity Spark mission totals
- Evidence Lock behavior
- Free Experiment requirement
- Question Gate behavior
- Supabase schema

## Local smoke test

1. Run `npm run build`.
2. Run `npm run dev`.
3. Start a fresh session and confirm the title reads `P1.1C`.
4. Move Quip and confirm the Observation Screen gives a shadow-motion reward effect.
5. Move the lamp and confirm a beam-ripple reward effect.
6. Turn the lamp off and verify the short dark/star discovery moment.
7. Create a huge and tiny shadow and verify distinct HUGE / TINY effects.
8. Reach the blocker challenge and verify the second-shadow discovery pulses both blocker and wall.
9. Watch the five Compass segments charge as the five core discoveries complete.
10. Complete Evidence Lock, Free Experiment, Question Gate, and mission completion to verify no mission regression.
11. Press `P` and confirm mission telemetry remains intact.

## Design intent

P1.1C increases reward clarity without interrupting play. Discoveries should feel like the world noticed what the child did, rather than like invisible mission-state updates.
