# Install P1.1A

Extract this ZIP directly into the existing working ASKONAUTS project root and choose **Replace files in destination**.

Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
```

If the build succeeds:

```bat
npm run dev
```

## Smoke-test checklist

1. Quip, lamp, and blocker still drag reliably.
2. Lamp ON/OFF still works.
3. Shadow sizes and wall clipping remain correct.
4. Blocker casts the second shadow.
5. Question Compass still reaches Evidence Lock.
6. Free Experiment reaches 5/5.
7. Question Gate completes the mission at 20 Sparks.
8. Parent panel still reports the P1 mission metrics without button overlap.
9. Visual build label reads `P1.1A`.

The approved concept image is included under `docs/visual-reference/` as a visual target only; the game does not render it as a flat background.
