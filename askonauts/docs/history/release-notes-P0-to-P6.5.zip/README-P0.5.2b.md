# ASKONAUTS Shadow Box — P0.5.2b touch hotfix

Changes:
- Adds a dedicated invisible drag zone for the lamp body, matching the reliable Quip touch strategy.
- Keeps the ON/OFF switch separate from the lamp drag zone.
- Moves the lamp and its drag zone together.
- Tags telemetry as P0.5.2b.
- Allows the telemetry API to accept P0.5.2, P0.5.2a, and P0.5.2b so touch-hotfix sessions are not rejected.

Copy these files over the matching paths in the existing project, then run:

npm run build
npx vercel@latest deploy --prod
