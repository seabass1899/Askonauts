# ASKONAUTS P1.2B-HF3 — Interaction Feedback & Prop Animation

This hotfix keeps the grounded production prop art from HF2 and makes the four optional Light Lab props feel like responsive toys instead of static scenery.

## Telescope
- Stronger lens charge and focus response.
- The instrument physically scans/tilts on activation.
- A visible scan beam travels from the telescope toward the star window.
- A reticle/glint transition leads into the constellation reveal.

## Prism
- Stronger physical bounce/tilt response.
- Rainbow light spill expands across the bench.
- Spectral particles burst from the prism on activation.
- Existing rainbow reveal remains intact.

## Question Jar
- Multi-beat shake/bounce animation.
- Glass-light spill brightens during activation.
- Question marks and a Spark visibly escape the jar before the question card appears.
- Repeated taps continue cycling through the curiosity-question pool.

## Brass Dial
- The dial face now rotates independently; the pedestal stays planted.
- Energy rings counter-rotate and expand.
- A lab-wide color pulse and concentric energy wave make the control visibly affect the room.
- Repeated activations cycle the energy response.

## Shared interaction polish
- Desktop hover/touch affordance emphasis on all four props.
- Richer, object-specific synthesized SFX.
- Existing Quip reactions, secrets, mission logic, world telemetry, and science mechanics remain unchanged.

Build: `P1.2B-HF3`
