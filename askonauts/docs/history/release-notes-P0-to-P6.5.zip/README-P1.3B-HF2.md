# ASKONAUTS P1.3B-HF2 — Evidence Voice / Compass Timing Fix

Apply this hotfix over a working P1.3B-HF1 project.

## Fix

The Question Compass no longer opens at the same moment Quip begins saying:

> “Look at the rock’s shadow. We made that happen by blocking the light.”

New sequence:

1. Rock shadow appears.
2. 0.9 second visual observation beat.
3. Quip speaks the evidence line.
4. The game waits for speech completion.
5. 0.65 second reflective pause.
6. Question Compass opens.

`VoiceDirector.speakAndWait()` includes an end/error callback and a bounded timeout fallback so browser speech synthesis cannot deadlock mission progression.

## Files

- `src/game/systems/VoiceDirector.ts`
- `src/game/scenes/ShadowBoxScene.ts`

## Install

Extract over the P1.3B-HF1 project root and replace files, then run:

```bat
npm run build
npm run dev
```
