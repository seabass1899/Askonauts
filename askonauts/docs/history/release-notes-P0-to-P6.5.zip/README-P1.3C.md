# ASKONAUTS P1.3C — Real Light Sandbox

P1.3C builds directly on the working P1.3B-HF2 mission and keeps MissionDirector unchanged.

## What changes

- The lamp beam no longer aims at Quip.
- A reusable `LightConeSystem` owns beam/illumination geometry independently of Phaser presentation.
- Quip only casts a wall shadow while he is actually inside the light cone.
- Quip can be dragged out of the light while the lamp remains ON; his shadow disappears naturally.
- The production rock uses the same fixed cone test instead of a Quip-derived beam path.
- If the rock sits between the lamp and Quip on the direct light path, it can occlude Quip and remove his shadow.
- Existing shadow projection math, mission thresholds, discovery ledger, hints, voice, Evidence Lock, and Question Gate remain intact.
- Build marker is `P1.3C`.

## Design intent

The Light Lab should now support a real "what if?" experiment rather than guaranteeing a shadow at every Quip position. The renderer/simulation decides illumination; MissionDirector continues receiving only semantic shadow observations.

## First validation

1. Start the mission and confirm the opening Quip shadow is visible.
2. Drag Quip vertically outside the visible light cone while the lamp remains ON. His shadow should disappear.
3. Drag Quip back into the cone. His shadow should return.
4. Move Quip closer/farther while illuminated and confirm the P1.3A size behavior remains dramatic.
5. Reach Block It and confirm the rock only casts a shadow while inside the visible cone.
6. Put the rock between the lamp and Quip along the same light path. Quip's shadow should disappear while the rock blocks his direct light.
7. Move the rock aside and confirm Quip's shadow returns.
8. Complete Evidence Lock and the Question Gate to verify no mission regression.
