# Install P1.2D

Base expected: P1.2C-HF1.

Extract this ZIP into the ASKONAUTS project root and replace files when prompted.

Then run:

```bat
npm run build
npm run dev
```

Do not delete `.vercel`, `.env.local`, or `node_modules`.
