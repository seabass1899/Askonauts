# ASKONAUTS P6.1 — Full Clubhouse UI Overhaul

P6.1 rebuilds the Clubhouse presentation layer while preserving the P5.9 gameplay and progression systems.

## Major changes
- Unified command-bar header for mastery, Askonaut identity, Sparks, Journal, Tree, and Audio.
- Rebalanced Clubhouse spatial hierarchy with protected UI zones.
- Richer observatory environment rendered as live Phaser geometry, not baked UI artwork.
- Redesigned Star Window, Discovery Wall, Question Compass, Mission Board, Question Gate, Spark Vessel, and Trophy Dock.
- Dedicated character stage for Veya, canonical full-body Quip, and Teyo.
- Updated Clubhouse modal theme for Discovery Journal, Question Tree, and Mission Board.
- P5.9 missions, mastery, save data, Sparks, discovery state, and world routing remain intact.

## Deferred visual polish
- Final production art replacement for the vector clubhouse environment.
- More character expression sprites beyond the canonical Quip integration.
- Fine-grained mobile/responsive scaling after desktop playtest feedback.
