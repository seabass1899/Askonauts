# P5.2-HF1 Rollback — Remove Bad Quip Ear Repair

This overlay restores ClubhouseScene.ts to the P5.2-HF1 baseline.
It removes the artificial ear-extension geometry introduced in FIX1.

Apply over P5.2-HF1-FIX1, then run:

npm run build
npm run dev

Hard refresh with Ctrl+F5.
