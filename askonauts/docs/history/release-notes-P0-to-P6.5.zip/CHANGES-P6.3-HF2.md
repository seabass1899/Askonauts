# ASKONAUTS P6.3-HF2 — Overlay & Readability Cleanup 2

Focused cleanup of the canonical Clubhouse reconstruction. No gameplay or progression logic changes.

## Changes
- Build marker now reads `P6.3-HF2`.
- Dialogue is forced into one compact fixed ribbon immediately below the command bar so it cannot cover Veya, Quip, Teyo, trophies, or the lower character stage.
- Star Window live label/card removed; the illustrated environment provides the label and presentation while an invisible hotspot preserves interaction and hidden constellation behavior.
- Question Compass duplicate live title/count badge removed; the illustrated panel remains visible and a transparent hotspot preserves Question Tree navigation.
- Automatic TAP/TAP QUIP hint rings disabled to reduce visual clutter.
- Discovery Wall duplicate start/progress overlays removed; the illustrated panel remains the visual source of truth.
- Mission Board, Trophy panel, Question Gate, and Spark Vessel retain their canonical illustrated skins with live hotspots/state logic only.
- Existing P5.9 mission combinations, mastery, Sparks, Journal, Question Tree, identity, voice, and persistence are unchanged.
