# ASKONAUTS P5.4 — Hidden Surprises & Secrets

P5.4 adds session-based hidden delight moments to the existing ASKONAUTS worlds. These are not checklist requirements and do not inflate Curiosity Sparks. They reward playful experimentation.

## Hidden surprises

### Clubhouse — Secret Constellation
Tap the Star Window several times in quick succession. A temporary constellation appears and Quip reacts.

### Reflection Hunt — Light Dance
With the mirror selected, alternate mirror rotation directions several times quickly. The reflected-light area sparkles and Quip reacts.

### Spoon Lab — Dizzy Spoon
Flip the spoon repeatedly in quick succession outside an active mission. The viewer/reflection react and a playful sparkle moment appears.

### Funhouse Mirrors — Mirror Mayhem
Outside an active mission, select TALL → WIDE → WAVY → FLAT in quick succession. The reflection performs a short mayhem animation and Quip reacts.

## Design intent
- Hidden rather than announced.
- No lives or punishment.
- No Spark farming.
- Does not interfere with missions.
- Rewards experimentation and replay.

## Scope
Modified scenes only:
- ClubhouseScene.ts
- ReflectionHuntScene.ts
- UpsideDownSpoonScene.ts
- FunhouseMirrorsScene.ts
