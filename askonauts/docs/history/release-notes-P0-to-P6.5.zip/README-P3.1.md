# ASKONAUTS P3.1 — Reflection Challenges & Replayability

P3.1 builds directly on P3.0 Reflection Hunt. It keeps the four core reflection discoveries intact and adds a replayable Challenge Lab focused on controlling reflected light with mirror angle.

## New Challenge Lab

The Reflection Lab header now includes **CHALLENGE LAB**. Three short challenges are available:

1. **CENTER BOUNCE** — steer reflected light to the center target.
2. **SKY BOUNCE** — steer the beam to a higher target.
3. **FLOOR BOUNCE** — steer the beam to a lower target.

Each first-time completion is stored as a Reflection Hunt secret and awards one Curiosity Spark.

Completing all three also unlocks the bonus secret **TRIPLE BOUNCE**.

## Functional correction

Mirror rotation changes from 10-degree steps to 5-degree steps. This makes the reflection target positions intentionally reachable and gives the player finer control over the reflected beam.

## Persistence

The following secrets are persisted through the existing PlayerProgressStore:

- `perfect_bounce` — Center Bounce
- `sky_bounce` — Sky Bounce
- `floor_bounce` — Floor Bounce
- `triple_bounce` — bonus mastery secret

They also appear in the shared Discovery Journal.

## Scope

P3.1 is a functionality/replay pass. Final visual asset replacement for the mirror, spoon, rough panel, lab props, and effects remains part of the later visual polish phase.
