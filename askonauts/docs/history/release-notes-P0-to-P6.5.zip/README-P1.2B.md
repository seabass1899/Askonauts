# ASKONAUTS P1.2B — Interactive World

P1.2B turns the Light Lab from a mission backdrop into an optional discovery space.

## New optional interactions

- Star Window — tap the night sky for a shooting-star secret.
- Telescope — reveal a constellation in the window.
- Prism — split light into a temporary rainbow.
- Question Jar — cycle through curiosity prompts with Quip reactions.
- Brass Dial — trigger a playful lab-wide energy pulse.
- Pressure Plate — once the blocker is unlocked, placing it on the hidden floor plate opens a secret drawer.
- Quip Button — tapping Quip (without dragging) produces escalating reactions; the third tap reveals an easter egg.

None of these optional interactions advance the required Shadow Chase mission. They exist to reward exploration rather than replace the science loop.

## Telemetry

P1.2B adds raw-summary telemetry for:

- `worldInteractionCount`
- `uniqueWorldInteractions`
- `worldSecretsFound`

The protected admin dashboard also shows world-touch and secret counts. No Supabase schema migration is required; the new fields are stored in `raw_summary` and the existing event stream.

## Scene cleanup folded into P1.2B

The old opaque lower-corner foreground blocks are replaced by low-profile brass consoles so the safe-frame edges read as intentional lab dressing.
