# P1.1C changes

- Five-segment in-world Compass progress indicator
- Stronger Curiosity Spark collection toward the Compass
- Discovery-specific shadow / beam / darkness / size / blocker FX
- Evidence Lock and Free Experiment celebration effects
- Session-local discovery-streak feedback
- Discovery-specific synthesized SFX
- `discovery_fx:*` events recorded through existing delight telemetry
- Build id `P1.1C`
