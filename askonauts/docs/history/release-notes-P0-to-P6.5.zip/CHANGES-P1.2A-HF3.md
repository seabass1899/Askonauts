# P1.2A-HF3 changes

- replaces Phaser `ENVELOP` with `FIT` for the protected 1280×720 gameplay safe-frame
- adds a full-bleed scenic DOM backdrop behind the canvas for non-16:9 displays
- prevents ultrawide cropping of the Observation Screen, Parent control, lamp, Quip and experiment ring
- preserves all authored world coordinates and physics
- adds a small resize/aspect refresh helper
- telemetry/build ID updated to `P1.2A-HF3`
