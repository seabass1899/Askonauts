# ASKONAUTS P1.1A-HF3 — Interaction Affordances

This micro-pass keeps P1.1A-HF2 gameplay, mission logic, physics, and telemetry semantics intact while making first-use interactions easier to discover.

## Changes
- Quip gives a one-time subtle bob/ring invitation after 2.6 seconds of inactivity.
- The lamp gives a one-time subtle drag-ring / switch pulse shortly afterward.
- If the child still has not interacted after 8.5 seconds, a temporary ghost-drag cue demonstrates horizontal dragging on Quip, then the lamp.
- All hints immediately disappear after the first real interaction and do not return.
- The always-visible interaction rings are quieter and less visually dominant.
- The PARENT button is smaller/dimmer but remains accessible.
- Build identifier: `P1.1A-HF3`.

No mission thresholds, drag bounds, shadow math, Supabase schema, or parent-feedback flow changed.
