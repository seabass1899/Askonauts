# Install P6.4A-HF6

Apply this overlay over P6.4A-HF5.

Then run:

```bat
npm run build
npm run dev
```

Hard refresh the browser with `Ctrl + F5`.

Confirm the Spoon Lab marker reads `LIVE • P6.4A-HF6`.
