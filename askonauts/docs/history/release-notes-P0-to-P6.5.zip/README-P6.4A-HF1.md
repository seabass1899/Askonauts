# ASKONAUTS P6.4A-HF1 — Spoon Lab Spark API Build Fix

Apply this overlay over P6.4A.

Fixes the strict TypeScript build error caused by calling the nonexistent `PlayerProgressStore.getSparkCount()` method. Spoon Lab now uses the existing `getTotalSparks()` API, matching the Clubhouse implementation.

No gameplay or visual behavior is otherwise changed.
