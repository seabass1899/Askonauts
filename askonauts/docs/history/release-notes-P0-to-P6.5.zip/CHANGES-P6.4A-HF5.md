# ASKONAUTS P6.4A-HF5 — Control Mapping + Concave/Convex Cleanup

- Corrected bottom control hit zones to match the illustrated MOVE CLOSER, MOVE FARTHER, and FLIP SPOON buttons.
- Fixes FLIP SPOON incorrectly triggering the farther-distance action.
- Removed floating CONCAVE / CONVEX live buttons that overlapped Veya.
- The illustrated CONCAVE VS CONVEX card now toggles the spoon side through an invisible hotspot.
- Runtime marker updated to LIVE • P6.4A-HF5.
- No discovery, mission, mastery, Spark, persistence, or reflection-science logic changed.
