# P6.4D Reflection Lab Acceptance Checklist

1. Open Reflection Lab and confirm the header reads `REFLECTION LAB • P6.4D`.
2. Verify Journal, Tree, Settings, Audio, Clubhouse and LIGHT RESCUE still work.
3. Confirm Veya guide banner is legible and Veya/Quip render without blocking experiment controls.
4. Select MIRROR, SPOON, and ROUGH PANEL; confirm visual state and discoveries update.
5. Rotate the mirror left/right and confirm the reflected blue beam tracks the target.
6. Flip the spoon and confirm concave/convex behavior remains intact.
7. Complete/refire the Reflection clues and verify progress persists.
8. Start LIGHT RESCUE and complete each target challenge.
9. Open/close global overlays during normal play and confirm gameplay remains usable after closing.
10. Navigate away and back; verify discoveries, secrets, settings, and audio state persist.
