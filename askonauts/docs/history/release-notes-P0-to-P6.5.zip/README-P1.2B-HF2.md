# ASKONAUTS P1.2B-HF2 — Prop Grounding & Scene Integration

This hotfix integrates the four production props into the Light Lab instead of letting them read as floating sprites.

## Visual changes
- Telescope: bench contact shadow + brass foot reflection.
- Question Jar: bench contact shadow + blue glass spill + brass rest.
- Prism: display base + contact shadow + rainbow spill.
- Brass Dial: dedicated ornamental pedestal + contact shadow.

All P1.2B optional interactions and secrets are preserved.

Build: `P1.2B-HF2`
