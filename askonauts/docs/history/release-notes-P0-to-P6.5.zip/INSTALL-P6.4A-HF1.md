# Install

Copy the overlay into the project root, replacing the matching file, then run:

```bat
npm run build
npm run dev
```

Hard refresh with `Ctrl + F5` if needed.
