# ASKONAUTS P6.4A-HF6

Interaction-affordance and functional-control patch for Spoon Lab.

This patch preserves the P6.4A illustrated environment and existing Spoon Lab gameplay while making every prominent illustrated control trustworthy and responsive.
