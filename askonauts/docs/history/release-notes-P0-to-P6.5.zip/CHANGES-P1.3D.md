# P1.3D Changes

- Replaced Free Experiment interaction-count completion with semantic sandbox discoveries.
- Added `SandboxDiscoverySystem`.
- Added three sandbox discoveries: leaving the beam, blocker occlusion, giant shadow.
- Question Gate unlocks after any 2 of 3 discoveries.
- Each unique discovery awards one Curiosity Spark; repeats do not.
- Added discovery-specific Quip reactions and spoken lines.
- Reworked Free Experiment HUD around three hidden Light Lab Secrets.
- Remaining secrets stay discoverable through Explore More.
- Question Gate completion now displays Light Lab Secret progress.
- Replay button copy reflects whether secrets remain.
- Updated child-facing and telemetry build ID to `P1.3D`.
- MissionDirector remains renderer/Phaser independent.
