# ASKONAUTS P6.4A-HF8

Spoon Lab button-highlight geometry correction.

## Fixes
- Recalibrates the left activity-card hotspots to the actual illustrated button bounds.
- Corrects the first left card, which was both too far left and too high.
- Expands the right Experiment Tools hover/press regions vertically to match the painted cards.
- Normalizes the three bottom control hotspots to the illustrated button widths.
- Draws feedback in hotspot-local coordinates so press scaling no longer shifts the highlight toward the screen origin.
- Insets hover/press feedback from the painted neon rim so it reads as part of the button rather than a floating rectangle.
- Prevents delayed hover redraws from leaving a stale highlight after the pointer has already exited.
- Preserves all existing Spoon Lab experiment behaviors.

Expected runtime marker: `LIVE • P6.4A-HF8`.
