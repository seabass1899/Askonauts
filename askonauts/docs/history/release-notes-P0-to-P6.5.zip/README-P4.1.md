# ASKONAUTS P4.1 — Spoon Lab Replay & Challenge Layer

P4.1 extends Upside-Down Spoon with a replayable Challenge Lab and clearer distance feedback.

## New challenges
- FLIP IT — make the concave reflection turn upside down.
- MAKE IT HUGE — move close enough to make the concave reflection upright and magnified.
- SHRINK IT — use the convex side to make the reflection small and upright.

Each first-time challenge completion earns a Curiosity Spark and persists as a Spoon Lab secret.
Completing all three unlocks the SPOON MASTER mastery secret.

## Distance clarity
The viewer rail now labels FAR / MIDDLE / NEAR and displays a live viewer-to-spoon distance guide.

## Integration
The four new challenge/mastery secrets appear in the Discovery Journal and use the same PlayerProgressStore as the rest of ASKONAUTS.
