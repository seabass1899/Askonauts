# P1.2B-HF5 Changes

- Fixed Brass Dial native-scale blow-up after interaction.
- Added defensive scale reset before each dial tween.
- Changed dial pulse to scale relative to its authored display size.
- Build identifier updated to `P1.2B-HF5`.
- Telemetry API accepts the new build identifier.
