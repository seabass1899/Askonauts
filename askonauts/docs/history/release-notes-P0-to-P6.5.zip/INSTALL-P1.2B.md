# Install P1.2B

Extract this ZIP into the existing ASKONAUTS project root and choose **Replace files in destination**.

Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
npm run dev
```

Expected build marker in the Light Lab:

`SHADOW CHASE • P1.2B`

Suggested smoke test:

1. Tap the star window.
2. Tap the telescope.
3. Tap the prism.
4. Tap the Question Jar twice.
5. Tap the brass dial.
6. Tap Quip three times without dragging him.
7. Progress until the blocker unlocks, then drag the blocker onto the subtle floor plate near the center-right floor.
8. Complete Shadow Chase normally and verify the Question Gate still works.
