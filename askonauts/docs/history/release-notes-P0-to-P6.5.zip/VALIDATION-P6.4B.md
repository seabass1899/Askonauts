# P6.4B Validation

## Static validation
- TypeScript: **PASS** (`tsc --noEmit`)
- Stale Spoon header `sprintHit`: **removed**
- Stale Spoon header `challengeHit`: **removed**
- Spoon duplicate `VoiceDirector` floating toggle: **removed via `AudioManager` + `showToggle:false`**
- P6.4A-HF8 interaction controls: **preserved**

## Runtime regression checklist

### Header
- [ ] JOURNAL opens Discovery Journal.
- [ ] TREE opens Question Tree.
- [ ] SETTINGS opens Settings.
- [ ] AUDIO toggles master audio and shows acknowledgement.
- [ ] CLUBHOUSE returns home.

### Journal
- [ ] Close returns to Spoon Lab without restarting it.
- [ ] Discovery cards select correctly.
- [ ] `TRY IT AGAIN` routes to the correct world.

### Tree
- [ ] Mystery/available/completed states match progress.
- [ ] Available world nodes route to the correct world.
- [ ] Close returns to Spoon Lab.

### Settings
- [ ] Master Audio persists.
- [ ] Voice setting persists.
- [ ] SFX setting persists.
- [ ] Text-size preference persists.
- [ ] Reset Settings restores defaults.
- [ ] Reset Progress requires two taps.

### Spoon Lab regression
- [ ] Upside-Down Spoon preset works.
- [ ] Concave/Convex works.
- [ ] Spoon Sizes works.
- [ ] Creative Lab gating works.
- [ ] Rotate / Zoom / Light / Reset work.
- [ ] Move Closer / Move Farther / Flip Spoon work.
- [ ] Discoveries still record.
- [ ] Spoon Sprint can still be launched from its proper mission flow.
- [ ] Current Discovery live copy is readable without baked-copy collision.
