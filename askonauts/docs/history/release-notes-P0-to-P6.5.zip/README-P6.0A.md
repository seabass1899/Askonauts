# ASKONAUTS P6.0A — Canonical Quip + Header/UI Cleanup

Apply this overlay over P5.9.

## Included
- Canonical full-body Quip Clubhouse asset
- Quip scaled to the same visual body height as Veya and Teyo
- Header utility rail cleanup
- Audio control moved into the far-right header utility position
- Mastery, Askonaut identity, Sparks, and Audio spacing normalized
- Clubhouse build marker updated to P6.0A

## Deliberately not changed
- Mission logic
- Question Tree logic
- Discovery Journal logic
- Sparks/mastery persistence
- P5.9 Dynamic Mission Combination Engine

This is the first P6 visual-integration slice. Larger Clubhouse panel/restyling work follows after this baseline is verified.
