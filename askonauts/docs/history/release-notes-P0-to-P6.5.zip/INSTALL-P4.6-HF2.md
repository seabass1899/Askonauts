# Install

Apply this overlay on top of P4.6-HF1, then run:

npm run build
npm run dev
