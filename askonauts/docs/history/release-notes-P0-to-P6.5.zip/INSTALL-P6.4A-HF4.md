# Install — P6.4A-HF4

Apply over P6.4A-HF3, then run:

```bat
npm run build
npm run dev
```

Hard refresh with Ctrl+F5 if the browser has cached the previous scene.
