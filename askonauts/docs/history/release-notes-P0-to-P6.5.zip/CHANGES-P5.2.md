# P5.2 Changes

- Updated visible build markers to P5.2.
- Mission Board now shows a guide for each mission.
- LIGHT RESCUE:
  - Veya introduces prediction-first play.
  - Teyo labels each target objective.
  - Quip reacts to rescued targets.
  - Veya closes the mission with a science-oriented celebration.
- SPOON SPRINT:
  - Quip introduces the sprint.
  - Veya/Teyo/Quip each frame different spoon objectives.
  - Quip closes the mission.
- MIRROR MISSION:
  - Veya explicitly asks the player to predict before testing.
  - Character-specific prompts rotate by mirror effect.
  - Quip gives a gentle retry response on the first wrong choice for a step.
  - Teyo celebrates correct predictions.
  - Veya closes the mission.
- No save schema, Spark, world-completion, discovery, or challenge-ID changes.
