# Changes — P6.4A-HF4

- Removed duplicate live bottom button rectangles and labels.
- Added transparent interactive hit zones over the illustrated bottom controls.
- Preserved MOVE CLOSER, MOVE FARTHER, and FLIP SPOON actions.
- Updated runtime marker to P6.4A-HF4.
