# Install P1.2A

Extract the P1.2A ZIP directly into the existing ASKONAUTS project root and choose **Replace files in destination**.

Do not remove `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
npm run dev
```

Verify the title reads `SHADOW CHASE • P1.2A`.

Smoke-test Quip drag, lamp drag/toggle, blocker drag, Question Compass, Free Experiment and Question Gate before deployment.
