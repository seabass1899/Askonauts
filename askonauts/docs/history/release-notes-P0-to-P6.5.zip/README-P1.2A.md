# ASKONAUTS P1.2A — Production Art & Animation

P1.2A is the first production-oriented presentation pass for the Shadow Chase vertical slice.
It intentionally keeps the proven P1.1C science simulation and mission flow intact while replacing
prototype-grade motion and scene dressing with a more cohesive game presentation.

## What changed

- Quip now has a production motion rig: breathing, varied idle beats, squash/stretch dragging,
  landing, surprise, skeptical, joy and celebration poses.
- Quip reactions now use one integrated speech bubble instead of a separate reaction portrait.
- The Light Lab uses an enhanced production scenic plate with smoother scenic-to-floor blending,
  perspective floor seams, animated orrery, living Compass dock, floor reflections and more atmosphere.
- The discovery lamp now has a rotating lens assembly, animated lens sheen, switch/status glow and
  drag-responsive rotor motion.
- The blocker trolley now rolls, lifts the rock while dragging and settles mechanically on release.
- The Question Compass has a full hero-instrument treatment: rounded brass/violet housing,
  orbiting jewels, radial glow and a stronger evidence-lock animation.
- Build identifier is `P1.2A` and telemetry API accepts this build.

## What did not change

- optics math
- drag bounds and touch zones
- mission state machine
- discovery thresholds
- Free Experiment requirements
- Question Gate behavior
- Supabase schema

## Goal

The scene should now feel less like a prototype with effects layered on top and more like a single,
cohesive ASKONAUTS game space. P1.2A is the production baseline for the next pass, P1.2B —
Interactive World.
