# P1 Stage B changes

- Added reusable mission files under `src/game/missions/`.
- Integrated MissionDirector into `ShadowBoxScene`.
- Added one semantic move event per actual Quip/lamp drag.
- Added shadow Y-position to mission observation so vertical shadow movement counts.
- Connected light toggles and GIANT QUIP to the mission ledger.
- Added P1 mission data to existing anonymous telemetry.
- Added mission diagnostics to the adult Parent/Playtest panel only.
- Added `P1.0B` to server telemetry build allowlist.
- No blocker, Compass, evidence UI or Question Gate visuals yet; those begin in Stage C/D.
