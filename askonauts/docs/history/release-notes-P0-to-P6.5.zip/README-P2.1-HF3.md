# ASKONAUTS P2.1-HF3 — Welcome Experience Build Fix

This hotfix corrects the TypeScript `noUnusedLocals` build failure introduced in P2.1-HF2.

## Fix
- Removed the unused `progress` snapshot from `ClubhouseScene.create()`.
- Preserves the complete P2.1-HF2 ASKONAUT welcome/badge experience.
- Visible Clubhouse build marker is now `P2.1-HF3` for easy verification.

## Install
Extract over the current P2.1-HF2 project root and replace files.

Then run:

```bat
npm run build
npm run dev
```
