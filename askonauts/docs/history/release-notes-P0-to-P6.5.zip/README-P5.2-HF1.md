# ASKONAUTS P5.2-HF1

Focused Clubhouse visual hotfix for Quip's clipped ear silhouette. No gameplay logic changes.
