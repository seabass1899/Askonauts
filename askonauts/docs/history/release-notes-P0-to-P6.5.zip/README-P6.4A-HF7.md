# ASKONAUTS P6.4A-HF7

Precise hitbox alignment and rounded press feedback for Spoon Lab.

## Fixes
- Left-side activity hotspots aligned to illustrated button bounds.
- Right-side Experiment Tools hotspots aligned to illustrated button bounds.
- Hover/press feedback now uses rounded rectangles matching button shapes.
- Click areas stay inside the visible buttons instead of spilling beyond the edges.
- Existing Spoon Lab behaviors remain unchanged.
