# Install P6.4A-HF8

This package is a full build based on the supplied P6.4A-HF7 backup.

Run:

```bash
npm install
npm run build
npm run dev
```

Then hard-refresh the browser (`Ctrl+F5`).

Expected runtime marker: `LIVE • P6.4A-HF8`.
