# P4.6-HF2 — Explanation Panel Cleanup

- Moves Funhouse Mirrors science copy into a dedicated right-side explanation panel.
- Prevents WIDE / TALL / WAVY mirror geometry from overlapping instructional text.
- Moves clue/secret status into the same protected panel.
- Updates Funhouse Mirrors and Clubhouse build markers to P4.6-HF2.
- No discovery, progression, save, or mirror-behavior logic changes.
