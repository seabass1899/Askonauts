# P6.0A Changes

1. Replaced the temporary/cropped Clubhouse Quip sprite with the approved full-body canonical Quip.
2. Matched Quip's rendered height to Veya and Teyo (~200 px at the Clubhouse baseline).
3. Moved the VoiceDirector mute toggle into the top-right header utility rail.
4. Rebalanced mastery, identity, and Sparks chips so they do not collide with audio controls.
5. Added a deliberate header rail/background separator.
6. Preserved all P5.9 game systems and save data.
