# ASKONAUTS P4.6-HF3 — Mirror Mission + Label Readability

This overlay applies over P4.6-HF2.

## What changed
- Mirror-type label now renders above the mirror/frame/table with its own dark background so it remains readable in FLAT, TALL, WIDE, and WAVY modes.
- Added a post-discovery Mirror Mission replay layer.
- After all four mirror clues are discovered, the player can start a three-round prediction challenge.
- Missions ask the player to predict which mirror makes the face taller/narrower, wider/shorter, or warped.
- Wrong choices give a gentle retry prompt; correct predictions trigger a reaction and success feedback.
- The completion overlay now offers TRY MIRROR MISSION or RETURN TO CLUBHOUSE.
- No discovery IDs, Sparks, save schema, or Question Tree progression changed.
