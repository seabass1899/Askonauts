# ASKONAUTS P1.1A-HF1 Build Fix

This hotfix resolves the TypeScript errors reported after the P1.1A-HF1 visual integration patch.

## Fixes

1. `QuipCharacter.ts`
   - Removed use of `Phaser.Geom.Point`, which is not exposed by the installed Phaser typings.
   - The left-ear repair now uses the `Graphics` path API (`moveTo`, `lineTo`, `fillPath`, `strokePath`).
   - No drag geometry or gameplay logic changed.

2. `LightLabEnvironment.ts`
   - Removed four obsolete procedural-decoration methods that were intentionally no longer called after the approved Light Lab image became the live scenic plate.
   - This resolves `noUnusedLocals` / TS6133 errors without reintroducing duplicate room art.

## Install

Extract into the existing project root and replace files when prompted.

Then run:

```bat
npm run build
```

If successful:

```bat
npm run dev
```
