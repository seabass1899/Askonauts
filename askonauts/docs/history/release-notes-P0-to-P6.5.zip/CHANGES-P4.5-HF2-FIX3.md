# Changes — P4.5-HF2-FIX3

- Restores Veya Clubhouse texture.
- Restores Teyo Clubhouse texture.
- Restores Quip idle texture.
- No TypeScript, save-data, progression, Spoon Lab, or Clubhouse logic changes.
- Preserves the P4.5-HF2-FIX2 ViewerFace cleanup.
