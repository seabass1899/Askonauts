# ASKONAUTS P1.2B-HF4

Targeted hotfix for two playtest findings from HF3:

1. The Question Jar could grow to a huge scale because its tween was resetting to scale `1` rather than the smaller scale created by `setDisplaySize()`.
2. The Prism reaction needed more motion beyond the existing static rainbow rays.

HF4 stores the true authored scale of both sprites and restores it after animation. The Prism also gets a more visible spectral light-dance effect.

## Smoke test
- Tap Question Jar several times in succession. It should shake/squash and always return to its original size.
- Tap Prism. It should rock/pulse, throw animated multicolor rays, expand the rainbow spill, show the spectral orbit, and settle back to its baseline pose.
- Verify Telescope, Brass Dial, Quip, mission progression, and Question Gate still work.
