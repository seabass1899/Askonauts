# Changes — P4.5-HF2

## ViewerFace
- Added fuller torso/shoulder treatment for the physical viewer.
- Added reflection-only optical stretch support to `transitionState()`.
- Slightly softened reflected-face opacity during state transitions.

## UpsideDownSpoonScene
- Added state-specific optical distortion values for convex, concave-far/middle, and concave-near reflection states.
- Added smooth lateral reflection movement as optical state changes.
- Increased reflection base size slightly for improved readability.
- Added extra spoon-bowl specular details: inner glow, lower reflection arc, and rim light.
- Refined concave/convex spoon surface tones.
- Updated visible build marker to P4.5-HF2.

## ClubhouseScene
- Updated build marker to P4.5-HF2.

## No gameplay changes
Progression, challenge criteria, discoveries, secrets, Sparks, save data, and navigation remain unchanged.
