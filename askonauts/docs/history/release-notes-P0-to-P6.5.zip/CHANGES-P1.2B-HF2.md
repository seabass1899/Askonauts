# P1.2B-HF2 Changes

## Prop Grounding & Scene Integration

- Telescope lowered onto the lab workbench with a contact shadow and brass foot reflection.
- Question Jar lowered onto the bench with a contact shadow, brass rest and subtle blue glass light spill.
- Prism grounded on a small brass display base with a contact shadow and persistent low-level rainbow reflection.
- Brass Dial moved onto a short ornamental pedestal with foot, stem, collar and contact shadow.
- Interaction zones and reward origins were shifted with the props so the existing P1.2B behavior remains aligned.
- No mission-state, science, secrets, drag mechanics or Supabase schema changes.
- Build identifier: `P1.2B-HF2`.
