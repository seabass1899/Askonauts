# Install

Overlay this ZIP onto your current P6.4 project, preserving folders, then run:

npm run build
npm run dev

Hard refresh with Ctrl+F5 if the browser cache still shows the prior version.
