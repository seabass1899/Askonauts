# ASKONAUTS P4.0 — Upside-Down Spoon

P4.0 adds the third playable Discovery World to ASKONAUTS Question World.

## Core question
**Why does a spoon flip your reflection?**

## Core discoveries
- **CONVEX: SMALL + UPRIGHT** — the outside curve keeps the image upright and smaller.
- **CONCAVE: UPSIDE DOWN** — farther from the inward curve, the image becomes inverted.
- **UPRIGHT AGAIN** — very close to the concave side, the image becomes upright and magnified.
- **DISTANCE CHANGES THE IMAGE** — moving the viewer changes the image even when the spoon stays the same.

## Secret
- **FLIP POINT** — cross the near/middle boundary on the concave side and discover where orientation changes.

## Integration
- registered as a playable world
- launched from the Question Tree and Clubhouse Question Gate after Reflection Hunt
- uses the existing ASKONAUT identity and age-band profile
- persists Sparks, discoveries, secret, and completion
- writes into the shared Discovery Journal
- completion reveals **Why do funhouse mirrors stretch and squash us?**

## Visual note
This remains a systems-first build. The spoon and reflection graphics are functional placeholders pending the scheduled cross-world visual asset polish pass.
