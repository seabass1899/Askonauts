# Install

Extract this ZIP into the ASKONAUTS project root and allow the files to merge into `public/assets/characters/...`.

Then run:

```bat
npm run build
npm run dev
```

After Vite restarts, hard-refresh once with `Ctrl+F5` so the browser retries the textures that failed in the previous session.
