# ASKONAUTS P3.0 — Reflection Hunt

P3.0 introduces the second playable ASKONAUTS Discovery World and proves that the Question World architecture can support more than Shadow Chase.

## Core question
**Why can we see ourselves in some things?**

## Core discoveries
- MIRROR BRIGHT — smooth mirrors reflect light clearly
- ROUGH SCATTER — rough surfaces scatter reflected light
- ANGLE MATTERS — rotating a mirror changes where reflected light goes
- CURVED REFLECTION — curved shiny surfaces change the reflected image

## Secret
- PERFECT BOUNCE — rotate the mirror until the reflected beam lands on the glowing target

## Ecosystem integration
- Reflection Hunt is a registered playable world.
- The Clubhouse Question Gate launches Reflection Hunt after Shadow Chase is complete.
- The Question Tree reports Reflection Hunt as READY TO EXPLORE / COMPLETED.
- Completing Reflection Hunt reveals the Upside-Down Spoon question branch.
- Reflection discoveries and the Perfect Bounce secret persist in PlayerProgressStore.
- Reflection discoveries appear in the shared Discovery Journal.
- TRY IT AGAIN routes Reflection entries back to Reflection Hunt.
- Curiosity Sparks from Reflection Hunt contribute to the same persistent total.
- ASKONAUT identity and saved age-band data are preserved.

## Design boundary
P3.0 intentionally does not fully answer the spoon-inversion question. The curved-spoon experiment creates the next question rather than collapsing Reflection Hunt and Upside-Down Spoon into one lesson.
