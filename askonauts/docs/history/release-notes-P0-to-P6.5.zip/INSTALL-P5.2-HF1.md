# Install

Apply this overlay over your current P5.2 project.

Then run:

```bat
npm run build
npm run dev
```

Hard refresh the browser with Ctrl+F5 if the previous Clubhouse scene is still cached.
