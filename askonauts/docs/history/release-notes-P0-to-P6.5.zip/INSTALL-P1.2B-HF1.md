# Install P1.2B-HF1

Extract this archive directly into the existing ASKONAUTS project root and choose **Replace files in destination**.

Keep the existing `.vercel`, `.env.local`, and `node_modules` directories.

Then run:

```bat
npm run build
npm run dev
```

Verify the title reads `SHADOW CHASE • P1.2B-HF1` and test Telescope, Prism, Question Jar and Brass Dial.
