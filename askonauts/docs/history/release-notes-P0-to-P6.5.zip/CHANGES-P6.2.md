# P6.2 Changes

- Build marker updated to P6.2.
- Star Window now uses the illustrated environment artwork with a live hotspot + compact label only.
- Question Compass now uses the illustrated brass body; Phaser keeps the live question mark, state count, pulse, and interaction.
- Question Gate now uses the illustrated portal; Phaser keeps live state/pulse/interaction and label.
- Spark Vessel now uses the illustrated vessel; Phaser adds live Spark motes, status, pulse, and interaction.
- Teyo's illustrated workbench replaces the flat Phaser table; the hotspot remains live.
- Discovery Wall and Mission Board changed to semi-transparent premium panels with lighter framing.
- Trophy dock moved and softened to reduce visual competition with the room and characters.
- Discovery Journal, Question Tree, Mission Board, derived-discovery, and rank-up overlays use lighter dimming and more transparent navy panels so the Clubhouse remains visually present behind them.
- Gameplay and persistence logic unchanged.
