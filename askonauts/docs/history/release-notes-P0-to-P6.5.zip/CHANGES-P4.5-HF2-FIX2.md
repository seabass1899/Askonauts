# Changes — P4.5-HF2-FIX2

- Removed the pointed purple torso wedge by replacing the main torso triangle with a centered rounded ellipse.
- Kept the small white collar triangles; these remain contained within the bust and are not the artifact.
- Preserved ViewerFace expressions and reflection mode.
- Preserved HF2 non-uniform optical distortion.
- Preserved animated spoon flip and viewer movement.
- Updated build/version markers only.
