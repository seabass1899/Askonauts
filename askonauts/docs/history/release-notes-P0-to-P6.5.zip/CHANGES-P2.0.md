# P2.0 changes

- Replaced dashboard-style Clubhouse with an interactive home-world composition.
- Added canonical Veya and Teyo Clubhouse sprites.
- Added interactive Quip with rotating comic responses.
- Added physical Question Compass and Question Gate interactions.
- Added progress-driven Discovery Wall.
- Added progress-driven Curiosity Spark Vessel.
- Added interactive invention table and star-window secret.
- Added ambient/idle animation throughout the room.
- Kept Shadow Chase as a registered world and P1.4 progress persistence intact.
- Updated playtest build marker to `P2.0`.
