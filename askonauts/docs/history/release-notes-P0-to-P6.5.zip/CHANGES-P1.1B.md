# P1.1B changes

- Challenge framing for core Shadow Chase stages
- Curiosity Spark counter and stage reward FX
- Spark flight / clue celebration effects
- Quip stage-specific dialogue and celebration motion
- Quip ambient idle beat
- Living Light Lab twinkles and gauge motion
- Optional shooting-star Lab Secret
- Discovery and secret SFX additions
- `delight_event` telemetry, admin derived count, CSV export
- Build id `P1.1B`
