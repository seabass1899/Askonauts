# P2.1 changes

- Added versioned ASKONAUT identity fields to PlayerProgressStore.
- Added non-destructive migration from progress schema v1 to v2.
- Added first-run identity setup overlay.
- Added touch-friendly HTML name input for mobile virtual keyboards.
- Added Star / Builder / Comet identity emblems.
- Added Violet / Gold / Cyan / Rose identity accents.
- Added persistent editable identity chip to Clubhouse header.
- Personalized Veya/Teyo Clubhouse dialogue with ASKONAUT name.
- Added ASKONAUT identity to Shadow Chase header.
- Updated visible Clubhouse/Light Lab build markers to P2.1.
- Updated playtest telemetry build marker to P2.1.
