# ASKONAUTS P1.3B-HF1 — DelightSystem Build Hotfix

Fixes TypeScript error:

`Property 'hideForCinematicTransition' does not exist on type 'DelightSystem'.`

The P1.3B ShadowBoxScene correctly calls this presentation helper during cinematic stage transitions, but the method was missing from the packaged DelightSystem implementation.

This hotfix restores the helper while preserving P1.3B's retract timer behavior.

## Install
Extract directly over the current P1.3B project root and replace files.

Then run:

    npm run build

