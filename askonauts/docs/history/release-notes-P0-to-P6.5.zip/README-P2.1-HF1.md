# ASKONAUTS P2.1-HF1 — Clubhouse Build Fix

Removes an unused `progress` local variable in `ClubhouseScene.create()` that caused TypeScript TS6133 when `noUnusedLocals` is enabled.

No gameplay, identity, persistence, UI, or mission behavior changes.

Install over P2.1 and replace files, then run:

```bat
npm run build
npm run dev
```
