# Install P1.4

Apply this ZIP over the working **P1.3D** project and replace files.

Then run:

```bat
npm run build
npm run dev
```

Expected startup: **ASKONAUTS Clubhouse**. Choose **ENTER LIGHT LAB** to launch Shadow Chase.

After completing Shadow Chase, choose **RETURN TO CLUBHOUSE**. The Clubhouse should show completion, persisted Sparks/discoveries/secrets, and Reflection Hunt as an unlocked upcoming question.
