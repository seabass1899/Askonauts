# Install ASKONAUTS P2.0

Expected base: **P1.4 Question World Foundation** with P1.3D/P1.3C hotfixes already applied in the working project.

1. Back up the current project.
2. Extract the P2.0 ZIP over the project root.
3. Choose **Replace files in destination**.
4. Do not delete `.env.local`, `.vercel`, or `node_modules` from the local working project.
5. Run:

```bat
npm run build
npm run dev
```

## Smoke test

1. App opens in the interactive Clubhouse.
2. Veya, Teyo, and Quip are visible.
3. Tap each character and verify a response bubble.
4. Tap the Question Compass.
5. Before Shadow Chase is complete, tap the Question Gate and verify the Light Lab launches.
6. Finish/return from Shadow Chase.
7. Verify the Discovery Wall reflects saved progress.
8. Verify the Spark Vessel reflects saved Sparks.
9. Verify the Question Compass reveals Reflection Hunt after Shadow Chase completion.
10. Verify tapping the completed Shadow Chase plaque revisits the Light Lab.
11. Refresh the browser and verify persisted progress remains.
