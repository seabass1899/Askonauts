# Changes — P5.7

- Added speaker/persona support to VoiceDirector.
- Character personas use different voice selection preferences, pitch, and pacing while retaining browser TTS fallback.
- Clubhouse character taps now speak in-character as well as showing readable bubbles.
- Reflection Hunt assigns Veya/Teyo/Quip to their appropriate mission and reaction lines.
- Spoon Sprint gives Quip/Veya/Teyo distinct spoken roles.
- Mirror Mission gives Veya/Teyo/Quip distinct spoken roles.
- Removed redundant phrases such as “Quip says” when Quip is already the selected speaker voice.
- Updated visible build markers to P5.7.
- No Spark, discovery, mastery, mission-completion, or save-schema changes.
