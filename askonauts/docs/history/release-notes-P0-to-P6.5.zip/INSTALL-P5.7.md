# Install P5.7

Apply this overlay over your current P5.6-HF2 project.

Then run:

    npm run build
    npm run dev

Hard-refresh the browser if needed with Ctrl+F5.

The first browser TTS line may depend on which system voices are installed; the implementation falls back safely to an available English voice.
