# ASKONAUTS P6.4D — Reflection Lab World Makeover

P6.4D pivots from the stabilized P6.4C-HF1 application shell into the first production presentation pass: Reflection Lab.

## Scope
- Preserves Reflection Lab science mechanics and progression.
- Preserves the shared Journal / Tree / Settings / Audio / Clubhouse shell.
- Rebuilds the Reflection Lab presentation as a crystalline light observatory.
- Adds Veya and Quip to the world presentation using existing canonical character assets.
- Keeps operational copy, buttons, status, clues, and progress as Phaser runtime UI rather than baking changing text into artwork.
- Refreshes the light source, target receptor, clue tracker placement, surface selector, controls, status panel, and environment.

## Baseline
Built directly from accepted P6.4C-HF1.

## Validation
`npx tsc --noEmit` passes with the project's dependencies available.
The Linux sandbox cannot complete Vite bundling because the provided dependency tree lacks Rollup's Linux optional native package. Run `npm install` on the target machine before `npm run build`.
