# Install P6.4-HF2

Apply this overlay on top of the current P6.4/P6.4-HF1 project.

Then run:

npm run build
npm run dev

Hard refresh with Ctrl+F5 if the browser still shows cached assets.
