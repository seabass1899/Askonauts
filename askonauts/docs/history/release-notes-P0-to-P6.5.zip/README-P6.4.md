# ASKONAUTS P6.4 — Reflection Lab World UI Makeover

This overlay upgrades the Reflection Lab presentation so it visually belongs with the P6 Clubhouse makeover while preserving all existing gameplay, mission randomization, discoveries, voice, mastery, Sparks, and persistence.

## Highlights
- New crystalline observatory / reflection-pool environment treatment
- P6-style command bar and world identity header
- Refined experiment panels, selectors, controls, and progress surfaces
- Existing Light Rescue mission and Reflection Challenge Lab remain functional
- No save migration or reset required

Apply over the current P6.3-HF2 project.
