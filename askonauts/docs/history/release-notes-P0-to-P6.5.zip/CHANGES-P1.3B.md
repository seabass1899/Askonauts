# P1.3B Changes

- Added `src/game/systems/VoiceDirector.ts`.
- Added child-facing speech for initial invitation, mission hints, stage discoveries, evidence flow, free experiment and Question Gate.
- Added persistent voice mute toggle.
- Delayed Question Compass reveal by 2400 ms after the rock-shadow discovery.
- Made Evidence Lock faster and second-tap skippable.
- Raised challenge ribbon and Compass text sizes for landscape-phone readability.
- Updated scene build marker to P1.3B and package version to `1.3.0-stage-b`.
