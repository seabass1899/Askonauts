# P5.4 Changes

- Added hidden Star Window constellation surprise in Clubhouse.
- Added Light Dance surprise in Reflection Hunt.
- Added Dizzy Spoon surprise in Spoon Lab.
- Added Mirror Mayhem surprise in Funhouse Mirrors.
- Hidden surprises are session-based and do not award repeatable Sparks.
- Suppressed experiment surprises during active missions so mission feedback remains clear.
- Updated visible build markers to P5.4.
