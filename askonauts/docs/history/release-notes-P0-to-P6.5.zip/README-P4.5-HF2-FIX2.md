# ASKONAUTS P4.5-HF2-FIX2 — Viewer Bust Cleanup

Focused visual hotfix on top of P4.5-HF2 FIX1.

## Changes
- Replaced the pointed viewer torso triangle with a compact rounded torso.
- Preserved the existing rounded shoulder silhouette, expressive ViewerFace, spoon flip animation, and HF2 optical reflection distortion.
- Updated visible build markers to `P4.5-HF2-FIX2`.
- No progression, challenge, clue, Spark, Journal, Question Tree, identity, age-band, or save-schema changes.

## Expected result
The purple wedge visible beneath/left of the viewer is removed. The viewer should read as a clean centered upper-body bust at FAR, MIDDLE, and NEAR.
