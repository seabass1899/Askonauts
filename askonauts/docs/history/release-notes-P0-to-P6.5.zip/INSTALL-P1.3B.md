# Install P1.3B

P1.3B is an overlay for a working **P1.3A** project.

1. Back up the current P1.3A project.
2. Extract this ZIP over the project root.
3. Choose **Replace files in destination**.
4. Do not delete `.env.local`, `.vercel`, `node_modules`, or existing public assets in your local project.
5. Run:

```bat
npm run build
npm run dev
```

## First validation

1. Leave the opening scene untouched for ~3 seconds: Quip should speak an invitation.
2. Complete the early discoveries: Quip should speak short reactions without changing mission progression.
3. Wait for a character-nudge hint: the existing visual nudge should also be spoken.
4. At Block It, create the rock shadow. The scene should remain visible for ~2.4 seconds before the Compass opens.
5. Tap the Compass once to begin locking evidence; tap again to finish immediately, or wait ~1.6 seconds.
6. Verify the speaker button toggles voice on/off.
7. Complete the mission through the Question Gate and verify the Gate voice lines do not block interaction.
