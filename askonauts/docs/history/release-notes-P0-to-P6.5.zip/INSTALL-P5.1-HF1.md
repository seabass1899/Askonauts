# Install

Apply this overlay on top of P5.1.

Then run:

```bat
npm run build
npm run dev
```

Hard-refresh the browser once (Ctrl+F5) so the new cache-busted character textures are loaded.
