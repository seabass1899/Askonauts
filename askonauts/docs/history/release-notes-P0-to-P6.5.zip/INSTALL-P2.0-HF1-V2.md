# Install P2.0-HF1-V2

1. Back up the current ASKONAUTS project.
2. Extract this ZIP over the project root and replace files.
3. Run `npm run build`.
4. Run `npm run dev`.
5. Hard refresh the browser once (Ctrl+F5).
6. Confirm the Clubhouse header reads `P2.0-HF1-V2`.

Expected immediate visual change: Veya and Teyo should be substantially larger than in HF1 and visibly darker/warmer in complexion. Quip should be slightly smaller.
