# ASKONAUTS P4.6-HF4 — Reflection Voice Repetition Fix

Focused Reflection Hunt hotfix.

## Fixes
- ANGLE MATTERS narration now plays only when the discovery is first earned.
- MIRROR BRIGHT, ROUGH SCATTER, and CURVED REFLECTION discovery narration are also gated to first discovery.
- Repeated mirror rotation and repeated surface selection no longer re-read the same discovery narration.
- Visual experiment behavior, challenge logic, Sparks, save data, and progression are unchanged.

## Build marker
Reflection Hunt now displays `P4.6-HF4`.
