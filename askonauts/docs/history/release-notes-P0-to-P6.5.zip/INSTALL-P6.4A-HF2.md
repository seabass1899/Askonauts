# Install P6.4A-HF2

Apply this overlay over P6.4A-HF1 / your current P6.4A project, preserving paths.

Then run:

```bat
npm run build
npm run dev
```

Hard refresh if needed:

```text
Ctrl + F5
```
