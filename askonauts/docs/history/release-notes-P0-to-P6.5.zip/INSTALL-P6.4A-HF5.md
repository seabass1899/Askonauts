# Install

Apply this overlay over P6.4A-HF4.

Then run:

npm run build
npm run dev

Hard-refresh the browser with Ctrl+F5 if needed.
