# ASKONAUTS P5.2-HF1-FIX1 — Quip Ear Repair

Focused Clubhouse visual hotfix.

- Replaces the previous tiny ear-tip workaround with full ear-extension geometry behind Quip.
- Preserves Veya, Teyo, mission logic, progression, Sparks, and save data.
- Updates the Clubhouse build marker to P5.2-HF1-FIX1.
