# ASKONAUTS Shadow Chase — P1.3A

## Teaching Fidelity & Interaction Repair Pass

P1.3A is a contained repair pass on top of the working P1.2D Question Gate build. It preserves the full Shadow Chase mission architecture and does not replace the mission with the discarded earlier "Core Mission Clarity Reset" design.

### Fixed

1. **True shadow-size rendering**
   - ShadowSystem no longer clamps the visible Quip shadow to the observation-screen fit scale.
   - Mathematical projection scale is rendered directly.
   - Oversized shadows are cropped at the observation-screen edges instead of being shrunk to fit.
   - Quip starts farther from the lamp so the opening shadow is medium-sized and can visibly grow or shrink.

2. **Mission hints are now visible**
   - `MissionDirector.update.activeHint` is connected to scene presentation.
   - `pulse_quip`, `pulse_light`, `pulse_switch`, `pulse_wall`, `pulse_blocker`, `pulse_compass`, `pulse_gate`, and `character_nudge` now trigger visible cues.
   - MissionDirector remains Phaser-independent.

3. **Rock input priority**
   - `blockerDragZone` is always above Quip's drag zone for pointer hit testing.
   - Visual object depth remains independent from input priority.

4. **Phaser 4 WebGL mask removal**
   - Beam geometry is clipped by construction at the room ceiling/floor.
   - Quip and blocker shadows use crop-based observation-screen clipping instead of unsupported GeometryMask calls.

5. **Question Gate cleanup**
   - Gate assembly is shifted upward and CTA/Reflection Hunt copy receives more separation.
   - Gate awakening waits until Quip's preceding speech bubble has cleared.

6. **Telemetry build validation**
   - Replaced the brittle hard-coded build allowlist with a bounded ASKONAUTS build-ID pattern.
   - Client build ID is `P1.3A`.

No Supabase schema change is required.
