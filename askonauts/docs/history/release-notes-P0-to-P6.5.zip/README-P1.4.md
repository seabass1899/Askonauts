# ASKONAUTS P1.4 — Question World Foundation

P1.4 turns Shadow Chase from a standalone app into the first registered world inside the ASKONAUTS Question World architecture.

## Added

- `WorldRegistry` with Shadow Chase as the first playable world and Reflection Hunt as the next registered world.
- Persistent `PlayerProgressStore` using versioned local storage.
- Per-world persisted Curiosity Sparks, discoveries, sandbox secrets, completion state, and unlocks.
- New `ClubhouseScene` foundation. The application now boots into the Clubhouse instead of directly into Shadow Chase.
- Clubhouse world card launches the Light Lab.
- Shadow Chase completion persists progress and unlocks the Reflection Hunt question.
- Question Gate now has a true `RETURN TO CLUBHOUSE` path.
- `PLAY AGAIN` restarts Shadow Chase without resetting accumulated profile progress.
- If a Light Lab secret remains, `FIND LAST SECRET` returns to the sandbox instead of reloading the application.

## Architectural rule

Shadow Chase remains responsible for its simulation. Question World owns world registration and persistent player progression. The Clubhouse never needs to know shadow geometry.

## Build ID

Package version: `1.4.0-question-world-foundation`.
