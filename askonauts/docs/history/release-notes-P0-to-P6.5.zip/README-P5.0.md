# ASKONAUTS P5.0 — Gameplay & Delight Upgrade

P5.0 shifts ASKONAUTS from experiment-first interaction toward mission-first play.

## What changes

### Shadow Chase
Shadow Chase already uses the MissionDirector architecture and remains the reference world for mission-led discovery. No scene rollback is included in this overlay.

### Reflection Hunt — LIGHT RESCUE
After the world is completed, the new LIGHT RESCUE button starts a three-target steering mission. TOP, MIDDLE, and BOTTOM targets are shuffled each run. The child must control only mirror angle to steer the blue reflected beam through all three.

### Upside-Down Spoon — SPOON SPRINT
After the Spoon mystery is completed, SPOON SPRINT launches three reflection tricks in a randomized order: FLIP IT, MAKE IT HUGE, and SHRINK IT. Mission play is replayable and does not inflate Curiosity Sparks.

### Funhouse Mirrors — MIRROR MISSION
The existing prediction mission now includes all four mirror behaviors, including FLAT, in randomized order.

## Design intent
MISSION → PREDICT / MANIPULATE → TEST → SUCCEED → CELEBRATE

Mission replay does not add new persistent discovery or secret IDs. Existing progression and save data remain compatible.
