# Install

Apply this overlay over your current P5.1-HF1 project.

Then run:

```bat
npm run build
npm run dev
```

Hard refresh the browser if needed:

```text
Ctrl + F5
```
