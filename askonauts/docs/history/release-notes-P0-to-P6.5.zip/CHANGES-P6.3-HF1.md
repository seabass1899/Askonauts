# ASKONAUTS P6.3-HF1 — Overlay & Readability Cleanup

This hotfix keeps the P6.3 canonical Clubhouse reconstruction intact and removes live overlay clutter that was competing with the illustrated UI.

## Changes
- Moved character dialogue into a compact top ribbon so Veya, Quip, and Teyo are not covered.
- Removed the duplicate Discovery Wall progress strip that overlapped the lower world cards.
- Removed duplicate Spark Vessel count/state overlays; the live Spark total remains authoritative in the header.
- Removed duplicate trophy/mastery decoration already represented in the canonical artwork/header.
- Replaced the duplicate Question Compass title block with one small live question-count badge below the compass.
- Removed the extra Mission Board "tap" overlay because the illustrated panel already contains its CTA.
- Tightened Veya / Quip / Teyo nameplates.
- Simplified Journal / Question Tree header utility buttons so they no longer compete with Audio.
- Updated build marker to P6.3-HF1.

No mission logic, Sparks, mastery, world progression, save data, or replay systems were changed.
