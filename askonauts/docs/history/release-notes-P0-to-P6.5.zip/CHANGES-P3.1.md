# Changes — P3.1

## Added
- Reflection Challenge Lab overlay.
- Center Bounce replay challenge.
- Sky Bounce replay challenge.
- Floor Bounce replay challenge.
- Triple Bounce mastery secret after all three targets are completed.
- Journal definitions for all new Reflection challenge secrets.

## Changed
- Mirror rotation increment reduced from 10° to 5° for deliberate target aiming.
- Reflection progress HUD now reports Challenge completion (`x / 3 CHALLENGES`).
- Reflection Lab build marker updated to P3.1.
- Package version updated to `3.1.0-reflection-challenges`.

## Not changed
- Four P3.0 core Reflection Hunt discoveries.
- Player profile / age-band behavior.
- Shadow Chase.
- Question Tree progression logic.
- Clubhouse navigation.
