# ASKONAUTS P2.1-HF4 — Badge Layout Cleanup

This hotfix is a visual-only cleanup for the ASKONAUT badge modal introduced in P2.1-HF2/HF3.

## Changes
- Moves `WHAT SHOULD WE CALL YOU?` safely above the name controls.
- Adds spacing above the ASKONAUT symbol cards.
- Adds spacing above the badge-color swatches.
- Moves the primary action upward slightly.
- Moves `CANCEL` fully inside the modal frame.
- Slightly increases modal height to create breathing room.
- Visible Clubhouse marker updated to `P2.1-HF4`.

## Unchanged
- Identity persistence
- Name editing behavior
- Badge/emblem selection behavior
- Accent selection behavior
- Welcome celebration
- Clubhouse progression
- Shadow Chase / world navigation

## Install
Extract over the current P2.1-HF3 project root and replace files.

Then run:

    npm run build
    npm run dev

