# Install P5.3

Apply this overlay over your current P5.2-HF2 project.

Then run:

```bat
npm run build
npm run dev
```

Hard refresh the browser if needed with Ctrl+F5.
