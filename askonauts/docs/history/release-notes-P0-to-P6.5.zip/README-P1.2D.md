# ASKONAUTS Shadow Chase — P1.2D

## Question Gate Cinematic

Smoke-test the full Shadow Chase mission and verify:

1. Free Experiment completion transitions into the Question Gate sequence.
2. LIGHT, BLOCK, and SHADOW tokens converge into the Compass core.
3. Energy visibly travels from the Compass into the Gate.
4. The Gate assembles inside the Light Lab rather than opening as a large menu card.
5. Reflection Hunt is visible through the Gate, including the spoon/reflection teaser.
6. `TAP THE GATE` enters the cinematic.
7. `EXPLORE MORE` returns to the Lab and leaves a Gate marker.
8. Entering the Gate reaches the Reflection Hunt coming-soon teaser.
9. `BACK TO LAB` returns to exploration and the Gate can be reopened.
10. Parent/playtest telemetry still records Question Gate revealed, entered, and next-mission prompt events.
