# P6.4A-HF8 Changes

## UI geometry
- Left activity cards now use centers near x=176 instead of x=144, matching the actual art.
- Corrected left activity-card vertical centers/heights.
- Corrected Experiment Tools vertical centers/heights.
- Fine-tuned bottom control widths.

## Highlight rendering
- Feedback graphics are now centered locally on each hotspot.
- Press animation scales around the button center instead of world origin (0,0).
- Feedback is inset from the static neon border.
- Hover/press state is tracked explicitly so pointer-out reliably clears feedback.

## Compatibility
- No gameplay/science-state changes.
- No changes to Spoon Lab discovery logic, mission logic, progress persistence, or challenge gating.
