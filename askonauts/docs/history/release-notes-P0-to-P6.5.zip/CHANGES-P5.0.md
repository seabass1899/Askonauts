# P5.0 Changes

- Added Reflection Hunt LIGHT RESCUE mission mode.
- Added randomized TOP/MIDDLE/BOTTOM reflection target sequence.
- Added Spoon Lab SPOON SPRINT mission mode.
- Added randomized FLIP IT / MAKE IT HUGE / SHRINK IT mission sequence.
- Expanded Funhouse Mirror Mission from 3 to 4 prediction rounds, including FLAT.
- Mission replay does not award duplicate Sparks or create new persistent progression IDs.
- Updated world build markers to P5.0 where modified.
- Preserved P4.6-HF4 Reflection narration de-duplication fix.
