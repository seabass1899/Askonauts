# ASKONAUTS P3.2-HF1 — Challenge Clarity & Sky Bounce Fix

Apply this overlay on top of P3.2.

## Fixes
- Sky Bounce was mathematically unreachable with the 5-degree mirror step. Target positions are now aligned to reachable beam paths:
  - Sky: y=300 (~-5 degrees)
  - Center: y=382 (~0 degrees)
  - Floor: y=465 (~+5 degrees)
- Hit tolerance increased slightly to match the visible beam/target width.
- Challenge Lab now explains what “bounce” means: light hits the mirror and reflects toward the target wall.
- Each challenge explicitly tells the child to steer the BLUE reflected beam to the TOP, MIDDLE, or BOTTOM glowing target.
- Target-wall labels update for the active challenge.
- Reflection Lab build marker is P3.2-HF1.

## Validate
1. npm run build
2. npm run dev
3. Open Reflection Hunt > Challenge Lab.
4. Start Sky Bounce and rotate until the blue reflected beam hits the top glowing target.
5. Verify Center and Floor remain completable.
