# ASKONAUTS P6.4A-HF4 — Spoon Bottom-Control Deduplication

This hotfix removes the duplicate live-rendered MOVE CLOSER / MOVE FARTHER / FLIP SPOON buttons from Spoon Lab.

The illustrated P6.4A control bar remains visible. Transparent Phaser hit zones are aligned over those illustrated controls so all interactions still work normally.

Also updates the runtime marker to `LIVE • P6.4A-HF4`.
