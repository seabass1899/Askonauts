# ASKONAUTS P5.6-HF1

Focused Clubhouse layout hotfix.

The Discovery Trophy display now occupies its own wall-mounted zone directly beneath the Discovery Wall instead of sitting behind the character stage. This preserves the P5.6 evolving-Clubhouse reward system while making earned trophies immediately visible and tappable.

Quip's visual asset remains intentionally untouched in this phase and is still logged for a later canonical-art revisit.
