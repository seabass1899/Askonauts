# Install ASKONAUTS P2.2

Expected base: **P2.1-HF5**.

1. Back up the current project.
2. Extract this ZIP directly over the ASKONAUTS project root.
3. Replace files when prompted.
4. Run:

```bat
npm run build
npm run dev
```

## Quick validation

1. Clubhouse header shows `P2.2`.
2. Tap the Question Compass.
3. The Question Tree overlay opens.
4. With a fresh profile, Shadow Chase is **READY TO EXPLORE** and unrevealed branches remain mysteries.
5. With completed Shadow Chase progress, Shadow Chase is marked discovered/completed and Reflection Hunt appears as a newly revealed question.
6. If large + small shadow discoveries exist, the Shadow Size branch is marked discovered/completed and the Double Shadow branch is revealed.
7. Close the tree and confirm all normal Clubhouse interactions still work.

