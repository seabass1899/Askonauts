# ASKONAUTS P3.1-HF2 — Clubhouse Build Fix

Apply over P3.1-HF1.

## Fix
- Removes the unused `pulseGate()` method from `ClubhouseScene.ts`.
- Preserves the explicit completed-world revisit navigation introduced in HF1.
- Updates the visible Clubhouse build marker to `P3.1-HF2`.

No gameplay, progress, Reflection Lab, Challenge Lab, Question Tree, Journal, identity, age-band, or telemetry behavior is changed.
