# Install P1.2A-HF2

Extract the ZIP into the existing ASKONAUTS project root and choose **Replace files in destination**.

Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
```

If clean:

```bat
npm run dev
```

## Smoke check

1. The title reads `SHADOW CHASE • P1.2A-HF2`.
2. Landscape viewport is filled; no navy top/bottom dead bands and no duplicated scenic strip below the game.
3. Quip, lamp and blocker still drag normally.
4. Free Experiment starts as a compact card and retracts after roughly 2.3 seconds.
5. Shadow is entirely contained inside the Observation Screen and has no rectangular grey wash.
6. Question Gate keeps more of the Lab visible behind it.
7. Complete the mission and verify Parent telemetry still reports `complete`, 20 Sparks, Gate entered, and next mystery shown.
