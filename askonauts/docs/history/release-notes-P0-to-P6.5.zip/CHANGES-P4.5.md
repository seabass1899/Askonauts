# P4.5 Changes

## Visual production foundation
- richer Reflection Lab mirror, rough surface, spoon and target wall
- layered incoming/reflected beam glow
- more recognizable Spoon Lab utensil
- subtle viewer/reflection depth improvements
- optical halo around Spoon Lab experiment
- P4.5 scene/build markers

No gameplay or progress-model changes.
