# P4.5-HF1 Changes

- Added reusable `ViewerFace` Phaser component.
- Replaced simplistic viewer/reflection icons in Spoon Lab with expressive matched faces.
- Added curious, surprised, and happy face states.
- Added animated spoon flipping with input lockout and midpoint state swap.
- Added distinct concave/convex spoon shading.
- Added spoon shimmer effect.
- Added smooth viewer distance movement.
- Added smooth reflection scale/inversion transition.
- Added reaction feedback for flip point, challenge completion, and Spoon Mastery.
- Updated visible build marker to P4.5-HF1.
