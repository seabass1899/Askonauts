# Install P1.1B over P1.1A-HF3

Extract the ZIP into the existing ASKONAUTS project root and choose **Replace files in destination**.

Do not delete `.vercel`, `.env.local`, or `node_modules`.

Then run:

```bat
npm run build
npm run dev
```

Only deploy to Vercel after the local build and smoke test pass.
