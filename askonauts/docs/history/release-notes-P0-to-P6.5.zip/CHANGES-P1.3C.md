# P1.3C changes

- Added `LightConeSystem` for reusable beam geometry and illumination tests.
- Decoupled visible beam direction from Quip position.
- Quip shadow visibility now depends on actual illumination.
- Rock beam membership now uses the same fixed cone geometry.
- Added forgiving rock-to-Quip direct-ray occlusion.
- Preserved existing mission logic and semantic observation contract.
- Updated child-facing build marker to P1.3C.
