# Install P4.6-HF3

1. Apply this overlay on top of your working P4.6-HF2 project.
2. From the project root run:

```bat
npm run build
npm run dev
```

3. Open Funhouse Mirrors.
4. Verify each mirror label remains visible.
5. After all four clues are present, select START MISSION or use TRY MIRROR MISSION from the completion overlay.
