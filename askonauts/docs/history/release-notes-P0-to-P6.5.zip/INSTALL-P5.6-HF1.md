# Install P5.6-HF1

Apply this overlay over ASKONAUTS P5.6.

Then run:

```bat
npm run build
npm run dev
```

Hard refresh the browser if the previous Clubhouse remains cached:

```text
Ctrl + F5
```
