# ASKONAUTS P6.4A-HF5

Focused control-mapping hotfix for Spoon Lab.

Expected behavior:
- MOVE CLOSER changes only distance closer.
- MOVE FARTHER changes only distance farther.
- FLIP SPOON changes only concave/convex side.
- Clicking the illustrated CONCAVE VS CONVEX card also toggles the spoon side.
- No floating concave/convex buttons cover Veya.
