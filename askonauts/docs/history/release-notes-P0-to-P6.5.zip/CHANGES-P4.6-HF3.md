# P4.6-HF3 Changes

## Readability
- Raised mirror label to depth 16.
- Added opaque dark label backing/padding.
- Keeps FLAT MIRROR / VERTICALLY CURVED MIRROR / HORIZONTALLY CURVED MIRROR / MIXED-CURVE MIRROR readable regardless of mirror geometry.

## Gameplay
- Added MIRROR MISSION after all four clues are discovered.
- Three randomized prediction rounds: TALL, WIDE, WAVY.
- Player must predict the correct mirror effect rather than simply cycling all buttons.
- Gentle wrong-answer feedback and character reaction.
- Correct-answer feedback and star moment.
- Replayable without changing persistent progression or Spark counts.
- Completion overlay includes TRY MIRROR MISSION.
